<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Возникли ошибки
        </div>
    <?php endif; ?>

    <?php if(session()->has('message_success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo e(session()->get('message_success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('message_error')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo e(session()->get('message_error')); ?>

        </div>
    <?php endif; ?>


    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Все заказы</h3>
        </div>
        <div class="box-body">

            <?php if(count($orders)): ?>
                <div class="table-responsive">
                    <table class="table table-separated">
                        <tbody>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Дата</th>
                            <th>Имя</th>
                            <th>Телефон</th>
                            <th>Способ оплаты</th>
                            <th>Сумма</th>
                            <th>Билеты</th>
                            <th>Статус</th>
                        </tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($order->status ? 'bg-pale-success' : 'bg-pale-gray'); ?>">
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->created_at); ?></td>
                                <td><?php echo e($order->name); ?></td>
                                <td><?php echo e($order->phone); ?></td>
                                <td><?php echo e($payments[$order->payment]); ?></td>
                                <td><?php echo e($order->total); ?> ₽</td>
                                <td>
                                    <?php $__currentLoopData = $order->tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($ticket->event->name); ?><br><?php echo e($ticket->sector_name); ?> р:<?php echo e($ticket->row_name); ?> м:<?php echo e($ticket->place_name); ?> <?php echo e($ticket->price); ?> ₽</p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <div class="form-group">
                                        <select class="form-control order-list-status-change" data-order_id="<?php echo e($order->id); ?>" data-token="<?php echo e(csrf_token()); ?>">
                                            <option value="0"<?php echo e($order->status == 0 ? ' selected="selected"' : ''); ?>>Отменен</option>
                                            <option value="1"<?php echo e($order->status == 1 ? ' selected="selected"' : ''); ?>>Оформлен</option>
                                        </select>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>Нет заказов</p>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>