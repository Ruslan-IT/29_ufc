<?php $__env->startSection('content'); ?>
    <div class="menu-fixed no_mobile">
        <div class="wrapper">
            <img class="logo-menu" src="images/logo-in-menu.png" alt="logo Black Star">
            <nav id="menu-fixed">
                <ul>
                    <li data-menuanchor="home" class="no_mobile"><a href="#home">Главная</a></li>
                    <li data-menuanchor="concert" class="no_mobile"><a href="#album">концерт</a></li>
                    <li data-menuanchor="place" class="no_mobile"><a href="#place">Площадка</a></li>
                    <li data-menuanchor="media" class="no_mobile"><a href="#media">Клипы</a></li>
                    <li data-menuanchor="info" class="no_mobile"><a href="#info">Об Артисте</a></li>
                    <li data-menuanchor="lastpage"><a href="#lastpage">Будь в курсе</a></li>
                </ul>
            </nav>
            <div class="right">
                <a class="phone" href="tel:+74951505802">+7 (495) 150-58-02</a>
                <a class="btn buy" href="#" data-open-modal="1">Купить билет</a>
            </div>
        </div>
    </div>
    <div class="wrapper mobile">
        <div class="section lastpage mobile">
            <div class="inner">
                <div class="wrapper">
                    <div class="left">
                        <div class="center">
                            <h3>Григорий</h3>
                            <h1>Лепс</h1>
                        </div>
                        <div class="bottom">
                            <h2>16 Июля 2018 <span>|</span> 20:00</h2>
                            <p>Трибют концерт В день рождения</p>
                            <p>Спорткомплекс “олимпийский”, москва</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-down">
                <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
            </div>
        </div>
    </div>
    <div id="fullpage">
        <section class="section home" data-anchor="home">
            <div class="wrapper">
                <div class="right">
                    <h2>16 Июля 2018 <span>|</span> 20:00</h2>
                    <div class="center">
                        <h3>Григорий</h3>
                        <h1>Лепс</h1>
                    </div>
                    <p>Трибют концерт В день рождения</p>
                    <p>Спорткомплекс “олимпийский”, москва</p>
                    <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
                </div>
            </div>
            <div class="scroll-down">
                <a class="scroll-link" href="#video-sect">
                    <div class="mouse">
                        <span class="mouse__wheel"></span>
                    </div>
                </a>
            </div>
        </section>
        <section class="section concert" data-anchor="concert">
            <div class="inner">
                <div class="wrapper">
                    <img src="images/img-leps-2.jpg" alt="">
                    <div class="text">
                        <p>16 июля 2018 года на одной из главных концертных площадок страны, в спорткомплексе «Олимпийский», соберутся друзья Григория Лепса – известные и любимые артисты, которые исполнят его главные хиты и поздравят маэстро с днем рождения. Григорию Лепсу в этот день исполнится 56 лет! Подарок станет сюрпризом от многочисленных коллег и друзей музыканта, которые придумали и спродюсировали этот необычный проект.</p>
                        <p>В 2017 году Лепс стал абсолютным рекордсменом по выступлениям, после грандиозного тура дав сразу пять аншлаговых концертов в Москве, представив новый альбом «ТыЧегоТакойСерьезный» и став самым популярным артистом в стране по итогам народного голосования «Первого Канала».</p>
                        <p>Трибьют в день рождения объединил популярных артистов самых разных жанров, каждый из которых «споет Лепса» в собственной манере и аранжировке. Валерий Меладзе, Полина Гагарина, Филипп Киркоров, Тимати, Стас Михайлов, Руки Вверх!, Диана Арбенина, Светлана Лобода, Эмин и многие, многие другие артисты уже работают над уникальным материалом, который станет лучшим подарком на 56-летие артиста.</p>
                        <p>Подготовка к масштабному проекту началась задолго до его премьеры. Музыканты записывают песни из разных альбомов артиста, полагаясь на собственный вкус и интуицию. Выбирают сердцем, из множества песен Лепса находят и перепевают «свою», к которой лежит душа. Именно поэтому каждое выступление на сцене «Олимпийского» станет открытием не только для публики, но и для самого артиста, от которого все подробности проекта держат в секрете. </p>
                        <p>Концерт в таком уникальном формате пройдет впервые и станет редкой возможностью услышать песни Лепса в интересной, неожиданной, смелой, но неизменно хитовой трактовке. Безусловно, на сцену не раз поднимется и сам именинник. Григорий Лепс исполнит свои главные треки в традиционном звучании, настроении и характере – романтично, мощно и с драйвом.Трибьют-концерт по праву можно назвать одним из самых ожидаемых музыкальных событий лета 2018 года.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="section place" data-anchor="place">
            <div class="inner">
                <div class="column">
                    <div class="top">
                        <img src="images/logo-stadium.png" alt="">
                        <div class="when">16 Июля | 20:00</div>
                        <div class="where">
                            Спортивный комплекс олимпийский
                        </div>
                        <div class="addres">Россия, <span>г.</span> Москва, Олимпийский <span>пр.,</span> 16, <span>c.</span>1,2</div>
                    </div>
                    <div class="bottom">
                        <div id="map">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section media" data-anchor="media">
            <div class="inner">
                <div class="row">
                    <div class="block-left">
                        <a class="block" data-fancybox href="https://www.youtube.com/watch?v=PDm9HfLCagM">
                            <div class="info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70.22" height="80.04" viewBox="0 0 70.22 80.04">
                                    <path class="cls-1" d="M1319.03,4219.65L1249,4259.86l-0.19-80.01Z" transform="translate(-1248.81 -4179.84)" />
                                </svg>
                                <div class="text">
                                    <div class="auther">
                                        григорий лепс Ft. ани лорак
                                    </div>
                                    <div class="name">
                                        зеркала
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="block-right">
                        <a class="block first" data-fancybox href="https://www.youtube.com/watch?v=_sI_Ps7JSEk">
                            <div class="info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70.22" height="80.04" viewBox="0 0 70.22 80.04">
                                    <path class="cls-1" d="M1319.03,4219.65L1249,4259.86l-0.19-80.01Z" transform="translate(-1248.81 -4179.84)" />
                                </svg>
                                <div class="text">
                                    <div class="auther">
                                        григорий лепс Ft. green gray
                                    </div>
                                    <div class="name">
                                        зеркала
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a class="block second" data-fancybox href="https://www.youtube.com/watch?v=_sI_Ps7JSEk">
                            <div class="info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70.22" height="80.04" viewBox="0 0 70.22 80.04">
                                    <path class="cls-1" d="M1319.03,4219.65L1249,4259.86l-0.19-80.01Z" transform="translate(-1248.81 -4179.84)" />
                                </svg>
                                <div class="text">
                                    <div class="auther">
                                        григорий лепс Ft. Тимати
                                    </div>
                                    <div class="name">
                                        дай мне уйти
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section class="section info" data-anchor="info">
            <div class="inner">
                <div class="wrapper">
                    <div class="text">
                        <h2><span>григорий</span> лепс</h2>
                        <p>Григорий Лепс – талантливый певец с сильным мужским голосом, к которому невозможно оставаться равнодушным. Его оригинальная манера исполнения, неподражаемость, стиль и голос… Мощный завораживающий голос с уникальным диапазоном и колоритом, который задевает за живое. Каждая его песня – это отдельная история о чувствах, переживаниях, о любви и дружбе. </p>
                        <p>Родился Григорий в Сочи 1962 года в семье обычных рабочих. Учился в музыкальном училище и уже в юношеском возрасте начал выступать в местных ресторанах и других ночных заведениях, где курортная публика овациями встречала певца. Работая без выходных и свободного времени, Лепса часто преследовали стрессы, переутомления, от чего у молодого парня начались проблемы с алкоголем.</p>
                        <p>Вскоре он переезжает в Москву, чтобы попытаться испытать свою судьбу в этом большом столичном городе. Продолжает заниматься творчеством, поет в ресторанах, и снова снимает усталость алкогольными напитками. </p>
                        <p>В 1995 году, благодаря сотрудничеству с Виталием Маншиным, певец выпускает свою первую пластинку «Храни вас Бог». И сегодня мы можем с уверенностью сказать, что это было начало успешной карьеры многими обожаемого певца. Но постоянное употребление алкоголя и работа на пределе сил не могли пройти незаметно. У Григория начались проблемы со здоровьем, он попадает в больницу. Как твердят врачи, артист находился на грани жизни и смерти.
                            <br>Но, на счастье, судьба преподнесла ему второй шанс, который, надо сказать, Лепс использовал как надо.</p>
                        <p>Через два года выходит второй альбом исполнителя "Целая жизнь" с очередными хитами, в 2000 году свет увидела пластинка «Спасибо, люди», выпускаются новые клипы. Это был тяжелый период работы над собой, над своими ошибками и все это выливалось в грустные, но правдивые романтические песни. Ему поверили, с каждым днем у певца появлялось все больше поклонников разных возрастных категорий. </p>
                        <p>Далее последовали альбомы «На струнах дождя», «Парус», «Избранное», «Лабиринт», из которых рождались новые хиты, куда певец по-прежнему вкладывал всю душу.</p>
                        <p>В 2006 году вышел альбом «Вся моя жизнь», через год – сборники «Я живой» и «Вся жизнь моя – дорога». Певец начинает экспериментировать. Сначала был дуэт со Стасом Пьехой, результатом которого стала работа «Она не твоя», получившая признание публики и награду «Золотой граммофон». Начинается совместное творчество с Александром Розенбаумом, которое вылилось в альбом «Берега чистого братства». Были так же дуэты с Ириной Алегровой - композиция "Я тебе не верю", Валерием Меладзе – песня «Обернитесь», Тимати – песни «Реквием по любви» и «Лондон».</p>
                        <p>Григорий Лепс продолжает собирать полные залы, его концертный график расписан на годы вперед. Он продолжает оставаться одним из самых востребованных исполнителей музыкального шоу-бизнеса.</p>
                        <p>В Москве Лепс нашел не только славу и успех, но и любимую женщину, родившую ему детей. Анна стала третьей женой Лепса. По словам близких друзей Григория в Сочи, мужем и отцом он был всегда великолепным. Свою старшую дочь Ингу после развода с первой женой Светланой певец отправил учиться в Англию. А развелся с женой он, как говорят, из-за своего пристрастия к алкоголю и непростого характера. Светлана работала в казино, а после развода уехала в Турцию, где, говорят, живет и сейчас. Но, несмотря на расставание с Лепсом, она сохранила хорошие отношения с его матерью. После нее Григорий жил с другой девушкой, которая, бросив его во время смертельной болезни, уехала в Германию. Сейчас же наш любимый певец счастливо живет с танцовщицей Анной, с которой познакомился после одного из концертов. Нынешнюю супругу он увидел во время выступления Лаймы Вайкуле, у которой она работала в балете.</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="section lastpage" data-anchor="lastpage">
            <div class="inner">
                <div class="wrapper">
                    <div class="left">
                        <h2>16 Июля 2018 <span>|</span> 20:00</h2>
                        <div class="center">
                            <h3>Григорий</h3>
                            <h1>Лепс</h1>
                        </div>
                        <p>Трибют концерт В день рождения</p>
                        <p>Спорткомплекс “олимпийский”, москва</p>
                        <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="modal-tickets" data-modal="1">
        <div class="inner">
            <div class="wrap-content">
                <img src="images/icon-close-modal.svg" alt="" class="close">
                <div class="content maket show" data-content="1">
                    <h3><span>Григорий Лепс</span> <i>|</i> Трибют концерт в день рождения</h3>
                    <p class="where">16 июля 2018, в 20:00 | Москва, СК “Олимпийский”</p>
                    <div class="map-block">
                        <?php if($colors): ?>
                            <div class="map-prices">
                                <span class="caption">Фильтр по цене</span>
                                <ul>
                                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li p-min="<?php echo e($color['from']); ?>" p-max="<?php echo e($color['to']); ?>">
                                            <p class="price"><?php echo e($color['title']); ?></p>
                                            <div class="line" style="background:#<?php echo e($color['color']); ?>"></div>
                                            <div class="tooltip"><?php echo e($color['label']); ?></div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="map-scheme">
                            <div class="tooltip" data-for="place">
                                <p class="about-price"><span></span> ₽</p>
                                <p class="about-sector"></p>
                                <div class="block-right">
                                    <span class="about-row">
                                        <span>ряд</span>
                                        <span class="number"></span>
                                    </span>,
                                    <span class="about-place">
                                        <span>место</span>
                                        <span class="number"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="tooltip" data-for="sector">
                                <p class="name"></p>
                                <div class="about-price"><span class="number"></span> ₽</div>
                                <div class="free-place">Свободных мест: <span class="number"></span></div>
                            </div>
                            <div class="hover-place"></div>
                            <svg id="svg-map" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0" y="0">
                                <g id="svg-map-container">
                                    <filter id="dropShadow" x="-100%" y="-100%" width="300%" height="300%">
                                        <feDropShadow stdDeviation="3" flood-color="#444" flood-opacity=".5" dx="0" dy="0"></feDropShadow>
                                    </filter>
                                    <g class="sh-decor">
                                        <image href="<?php echo e(url('images/scheme_decor.png')); ?>" x="0" y="1.5" height="3177px" width="7846px"/>
                                    </g>

                                    <?php $__currentLoopData = $svg_conf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <g class="sh-sector" sn="<?php echo e($sector['title']); ?>" fp="0" pc="1000">
                                            <?php $__currentLoopData = $sector['places']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <circle class="pa" cx="<?php echo e($place['x']); ?>" cy="<?php echo e($place['y']); ?>" r="<?php echo e($sector['place_radius']); ?>" pp="<?php echo e($place['place']); ?>" pr="<?php echo e($place['row']); ?>" ps="<?php echo e($place['price']); ?>" style="fill: #<?php echo e($place['color']); ?>; stroke: #<?php echo e($place['color']); ?>" />
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <path class="sh-path" d="<?php echo e($sector['path']); ?>"/>
                                        </g>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <g class="sh-actived-places"></g>
                                </g>
                            </svg>
                            <div class="controls">
                                <button class="change-zoom svg-map-button" type="button" data-zoom_type="+"><img src="images/icon-controll-plus.png"></button>
                                <button class="change-zoom svg-map-button disabled" type="button" data-zoom_type="-"><img src="images/icon-controll-minus.png"></button>
                                <button class="disabled" id="reset" type="button">
                                    <img src="images/icon-controll-home.png" alt="">
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="panel-controll">
                        <div class="row">
                            <div class="clear">
                                <span><img src="images/trash-grey.svg" alt=""></span> очистить заказ
                            </div>
                            <div class="your-choose">
                                <span>Вы выбрали: </span>
                                <span class="choosed">
                                    <span class="button-open-popup">
                                        <span class="number">0</span> билета <img src="images/arrow-choose.png" alt="">
                                    </span>
                                <div class="wrap-popup">
                                    <div class="tickets popup">
                                        <h3>ваш заказ</h3>
                                        <ul class="list-tickets nice-scroll-right">
                                        </ul>
                                    </div>
                                </div>
                                </span>
                            </div>
                            <div class="total">
                                <span>Итого (<strong>₽</strong>): </span>
                                <span class="price">0</span>
                            </div>
                            <div class="btn buy">оформить заказ</div>
                        </div>
                    </div>
                </div>
                <div id="form-order" class="content order nice-scroll-right">
                    <div class="back" data-back><img src="images/arrow-left.png" alt=""> Назад</div>
                    <div class="stiker-top"></div>
                    <div class="top">
                        <div class="stiker">
                            <p class="top"><span>Григорий Лепс</span>
                                <br>Трибют концерт
                                <br>в день рождения</p>
                            <p>16 июля 2018, в 20:00
                                <br> Москва, СК “Олимпийский”</p>
                            <div class="btn buy" data-back>добавить билет</div>
                        </div>
                        <div class="your-choose-table">
                            <div class="row name-step">
                                <div class="number">1</div>
                                <div class="name">Ваш заказ:</div>
                            </div>
                            <div class="wrapper-top-table">
                                <table>
                                    <thead>
                                    <tr>
                                        <td>№</td>
                                        <td>Сектор</td>
                                        <td>Ряд</td>
                                        <td>Место</td>
                                        <td>Цена (<strong>₽</strong>)</td>
                                        <td><a href=""><img src="images/icon-remove.png" alt=""></a></td>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                            <div class="nice-scroll">
                                <div id="wrapper">
                                    <table id="form-order-ticket">
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="total-table right">
                                <span>Итого:</span>
                                <span class="price"><span class="number">0</span> ₽</span>
                            </div>
                        </div>
                    </div>
                    <div class="bottom">
                        <div class="left">
                            <div class="row name-step">
                                <div class="number">2</div>
                                <div class="name">Контактные данные:</div>
                            </div>
                            <div class="grid form">
                                <div class="field block-12">
                                    <input name="form_order_field_name" type="text" placeholder="Имя" required="required">
                                    <div class="error-field" id="error_field_name"></div>
                                </div>
                                <div class="field block-6">
                                    <input name="form_order_field_phone" type="text" data-inputmask="'mask': '+7 (999) 999 99 99', 'placeholder': '+7 (---) --- -- --'" required="required">
                                    <div class="error-field" id="error_field_phone"></div>
                                </div>
                                <div class="field block-6">
                                    <input name="form_order_field_email" type="email" placeholder="E-mail">
                                    <div class="error-field" id="error_field_email"></div>
                                </div>
                                <div class="field block-12 hide-if-card hide">
                                    <input name="form_order_field_address" type="text" placeholder="Адрес доставки">
                                    <div class="error-field" id="error_field_address"></div>
                                </div>
                                <div class="field block-12">
                                    <textarea name="form_order_field_comment" placeholder="Комментарий"></textarea>
                                    <div class="error-field" id="error_field_comment"></div>
                                </div>
                                <div class="block-12">
                                    <p><span>*</span> Поля обязательные для заполнения</p>
                                </div>
                            </div>
                        </div>
                        <div class="right">
                            <div class="row name-step">
                                <div class="number">3</div>
                                <div class="name">Способы оплаты:</div>
                            </div>
                            <div class="checkboxes">
                                <label>
                                    <input type="radio" name="form_order_field_payment" value="1" id="pay-card" checked="checked">
                                    <span class="name">Картой VISA / MASTERCARD</span>
                                    <span>После оформления заказа менеджер свяжется с Вами и отправит ссылку на оплату билетов</span>
                                    <img src="images/payment-final-2.png">
                                </label>
                                <label>
                                    <input type="radio" name="form_order_field_payment" value="2">
                                    <span class="name">Наличными курьеру</span>
                                    <span>Курьер подъедет в удобное для Вас время, предварительно предупредив по телефону. Оплата только наличными.</span>
                                </label>
                                <div class="error-field" id="error_field_payment"></div>
                                <input id="form_order_field_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                <div class="btn buy" id="form-order-button">купить билет</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-menu">
                <ul class="left">
                    <li><a href="">Как заказать?</a></li>
                    <li><a href="">Оплата</a></li>
                    <li><a href="">Контакты</a></li>
                </ul>
                <div class="right phone">
                    <a href="tel:+74951505802">+7 (495) 150-58-02</a>
                </div>
            </div>
            <div class="message">
                <div class="text" data-message="1">
                    <p>Спасибо за покупку! Ваш заказ <a href="">№ 163</a> успешно оформлен!</p>
                    <p>В ближайшее время с Вами свяжется менеджер для уточнения деталей.</p>
                    <p>По всем вопросам костельно заказа, обращайтесь по телефону:</p>
                    <p><a href="">+7 495 222 20 92</a></p>
                </div>
                <div class="text" data-message="2">
                    <p>Вы действительно желаете
                        <br>закончить покупку билетов?</p>
                    <div class="btn buy white" data-close-modal>Выйти</div>
                    <div class="btn buy" data-close-message>Продолжить покупку</div>
                </div>
                <div class="text" data-message="3">
                    <p>Вы действительно желаете
                        <br>очистить заказ?</p>
                    <div class="btn buy white" data-clear-cart>Очистить</div>
                    <div class="btn buy" data-close-message>Закрыть окно</div>
                </div>

                <div class="text" data-message="ticket-delete">
                    <p>Вы действительно желаете<br>удалить билет?</p>
                    <div class="btn buy white" data-ticket-delete>Удалить</div>
                    <div class="btn buy" data-close-message>Закрыть окно</div>
                </div>

                <div class="overlay"></div>
            </div>
        </div>
        <div class="overlay"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>