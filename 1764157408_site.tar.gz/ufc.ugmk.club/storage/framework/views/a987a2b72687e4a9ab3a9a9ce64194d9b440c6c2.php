<?php $__env->startSection('content'); ?>
    <div class="menu-fixed no_mobile<?php echo e(($message['status'] != 0) ? ' single-page' : ''); ?>">
        <div class="wrapper">
            <img class="logo-menu" src="images/logo.png" alt="Спасская башня 2018" title="Спасская башня 2018">
            <nav id="menu-fixed">
                <ul>
                    <li data-menuanchor="home" class="no_mobile"><a href="#home">Главная</a></li>
                    <li data-menuanchor="about" class="no_mobile"><a href="#about">О фестивале</a></li>
                    <li data-menuanchor="map" class="no_mobile"><a href="#map">Адрес</a></li>
                    <li data-menuanchor="video" class="no_mobile"><a href="#video">Видео</a></li>
                    <li data-menuanchor="members"><a href="#members">Участники</a></li>
                    <li data-menuanchor="buy"><a href="#buy">Будь в курсе</a></li>
                </ul>
            </nav>
            <div class="right">
                <a class="phone" href="tel:+74951505802">+7 (495) 150-58-02</a>
                <?php if($message['status'] == 0): ?>
                    <a class="btn buy" href="#" data-open-modal="1">Купить билет</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($message['status'] != 0): ?>
        <div class="page single-page">
            <div class="message">
                <?php if($message['status'] == 1): ?>
                    <h3>Ваш заказ оформлен!</h3>
                    <p><strong><?php echo e($message['name']); ?>, спасибо за покупку!</strong></p>
                    <p>Ваш заказ # <?php echo e($message['order']); ?></p>
                    <p>В ближайшее время с Вами свяжется менеджер для уточнения деталей. По всем вопросам, касательно заказа обращайтесь по телефону:</p>
                    <p><strong>+7 (495) 150-58-02</strong></p>
                <?php endif; ?>
                <?php if($message['status'] == 2): ?>
                    <h3>Ваш заказ не оформлен!</h3>
                    <p><strong><?php echo e($message['name']); ?>, повторите покупку!</strong></p>
                    <p>По всем вопросам, касательно заказа обращайтесь по телефону:</p>
                    <p><strong>+7 (495) 150-58-02</strong></p>
                <?php endif; ?>
                <a class="btn" href="<?php echo e(url('/')); ?>">На главную</a>
            </div>
        </div>
    <?php else: ?>
        <div class="wrapper mobile">
            <div class="section lastpage mobile">
                <a class="phone" href="tel:+74951505802">+7 (495) 150-58-02</a>
                <div class="inner">
                    <div class="wrapper">
                        <div class="left">
                            <div class="center">
                                <h2>Международный военно-музыкальный</h2>
                                <h1>Фестиваль <span>«Спасская башня»</span></h1>
                            </div>
                            <div class="bottom">
                                <p>Начало с 24 августа по 2 сентября 2018 года</p>
                                <p>Москва - Красная площадь</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bottom-down">
                    <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
                </div>
            </div>
        </div>
        <div id="fullpage">
            <section class="section home" data-anchor="home">
                <div class="wrapper">
                    <div class="inner">
                        <img src="<?php echo e(url('/images/logo-big.png')); ?>" alt="Спасская башня 2018" title="Спасская башня 2018">
                        <h2>Международный военно-музыкальный</h2>
                        <h1>Фестиваль <span>«Спасская башня»</span></h1>
                        <h4>Начало с 24 августа по 2 сентября 2018 года</h4>
                        <h3>Москва - Красная площадь</h3>
                        <a href="#" class="buy" data-open-modal="1">Купить билеты</a>
                    </div>
                </div>
                <div class="scroll-down">
                    <a class="scroll-link" href="#video-sect">
                        <div class="mouse">
                            <span class="mouse__wheel"></span>
                        </div>
                    </a>
                </div>
            </section>
            <section class="section concert" data-anchor="about">
                <div class="inner">
                    <div class="wrapper">
                        <img src="<?php echo e(url('/images/about.jpg')); ?>" alt="Спасская башня 2018" title="Спасская башня 2018">
                        <div class="text">
                            <p>Фестиваль «Спасская башня» — это захватывающее дух музыкально-театрализованное представление.</p>
                            <p>Это грандиозное «сражение» оркестров армий разных стран за любовь и восторги зрителей, которое разворачивается на фоне величественных стен Кремля. Органичное сочетание военной, классической, народной и эстрадной музыки, парадные дефиле военных оркестров и танцевальные шоу, показательные выступления с оружием, лазерные и пиротехнические эффекты — всё это делает фестиваль одним из самых ярких и запоминающихся зрелищ года.</p>
                            <p>Ежегодно проводится на Красной площади в Москве. «Спасская башня» — мероприятие, на котором каждый находит что-то своё. Одним нравятся чёткие, отлаженные движения военных. Другим — живая оркестровая музыка. Третьим — национальная культура представителей других стран. Для детей фестиваль подготовил программу «Спасская башня детям». Каждый день конное представление и световое шоу на Соборе Василия Блаженного. Все вечерние представления завершает грандиозный салют.</p>
                            <p>Проект «Спасская башня детям» — это захватывающие дух, яркие и живые впечатления для вашего ребёнка!</p>
                            <p>На фестивале будут работать 7 тематических площадок: сцена детского городка, творческий, исторический, музыкальный, патриотический и военный шатры, а также автодром. Квесты, конкурсы для всей семьи.</p>
                            <p>Конный манеж - лучшее конное шоу, визитной карточкой которого является совместная команда Кавалерийского почетного эскорта Президентского полка и Кремлевской школы верховой езды.</p>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section place" data-anchor="map">
                <div class="inner">
                    <div class="column">
                        <div class="top">
                            <img src="<?php echo e(url('/images/map-logo.png')); ?>" alt="Москва, Красная площадь" title="Москва, Красная площадь">
                            <div class="when">Начало с 24 августа</div>
                            <div class="where">Москва - Красная площадь</div>
                        </div>
                        <div class="bottom">
                            <div id="contact-map"></div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section media" data-anchor="video">
                <div class="inner">
                    <div class="row">
                        <div class="block-left">
                            <a class="block" data-fancybox href="https://www.youtube.com/watch?v=O5A8IAYRgUQ">
                                <img src="<?php echo e(url('/images/icon-play.png')); ?>" alt="Воспроизвести видео" title="Воспроизвести видео">
                                <div class="text"><div class="auther">10 лет фестивалю "Спасская Башня"</div></div>
                            </a>
                        </div>
                        <div class="block-right">
                            <a class="block first" data-fancybox href="https://www.youtube.com/watch?v=UUXzcFn4PNM">
                                <img src="<?php echo e(url('/images/icon-play.png')); ?>" alt="Воспроизвести видео" title="Воспроизвести видео">
                                <div class="text"><div class="auther">"Спасская башня 2017" - Беларусь - Рота Почётного караула и Оркестр ВС</div></div>
                            </a>
                            <a class="block second" data-fancybox href="https://www.youtube.com/watch?v=eVu2HQgaBbE">
                                <img src="<?php echo e(url('/images/icon-play.png')); ?>" alt="Воспроизвести видео" title="Воспроизвести видео">
                                <div class="text"><div class="auther">Андрей Давидян - Выступление на фестивале "Спасская Башня"</div></div>
                            </a>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section info" data-anchor="members">
                <div class="inner">
                    <div class="wrapper">
                        <div class="slider-title">
                            Учасники фестиваля
                            <div class="slider-buttons">
                                <div class="slider-buttons-left">&nbsp;</div>
                                <div class="slider-buttons-right">&nbsp;</div>
                            </div>
                        </div>
                        <div class="swiper-slider swiper-container">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <img src="<?php echo e($participant['image']); ?>" alt="<?php echo e($participant['title']); ?>" title="<?php echo e($participant['title']); ?>">
                                        <p><?php echo e($participant['title']); ?></p>
                                        <div class="read-more" data-open-modal="participant-<?php echo e($participant['id']); ?>">Подробнее</div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="section lastpage" data-anchor="buy">
                <div class="inner">
                    <h3>Международный военно-музыкальный</h3>
                    <h2>Фестиваль <span>«Спасская башня»</span></h2>
                    <h3>Москва - Красна площадь</h3>
                    <a href="#" class="btn buy" data-open-modal="1">Купить билеты</a>
                </div>
            </section>
        </div>

        <div class="modal-tickets" data-modal="1">
            <div class="inner">
                <div class="wrap-content">
                    <img src="<?php echo e(url('/images/icon-close.png')); ?>" alt="Закрыть" title="Закрыть" class="close">
                    <div class="content event-select show" data-content="0">
                        <h3>Международный военно-музыкальный фестиваль "Спасская башня 2018"</h3>
                        <p class="where">Москва, Красная площадь</p>
                        <hr>
                        <div class="checkout-event-select">
                            <p>Выбор даты</p>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Дата</th>
                                        <th>Мест в продаже</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-event_id="<?php echo e($event['id']); ?>" data-token=" <?php echo e(csrf_token()); ?>">
                                            <td><?php echo e($event['date']); ?></td>
                                            <td><?php echo e($event['count']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="content maket" data-content="1">
                        <div class="back" data-event-select-back><img src="images/arrow-left.png" alt=""> Назад</div>
                        <h3>Международный военно-музыкальный фестиваль "Спасская башня 2018"</h3>
                        <p class="where"><span class="event-date"></span> | Москва, Красная площадь</p>
                        <div class="map-block"></div>
                        <div class="panel-controll">
                            <div class="row">
                                <div class="clear">
                                    <span><img src="images/trash-grey.svg" alt=""></span> очистить заказ
                                </div>
                                <div class="your-choose">
                                    <span>Вы выбрали: </span>
                                    <span class="choosed">
                                        <span class="button-open-popup">
                                            <span class="number">0</span> билета <img src="images/arrow-choose.png" alt="">
                                        </span>
                                    <div class="wrap-popup">
                                        <div class="tickets popup">
                                            <h3>ваш заказ</h3>
                                            <ul class="list-tickets nice-scroll-right">
                                            </ul>
                                        </div>
                                    </div>
                                    </span>
                                </div>
                                <div class="total">
                                    <span>Итого (<strong>₽</strong>): </span>
                                    <span class="price">0</span>
                                </div>
                                <div class="btn buy mobile">
                                    Купить
                                    <span class="number billets"></span>
                                    билета за
                                    <span class="number price"></span> ₽</div>
                                <div class="btn buy">оформить заказ</div>
                            </div>
                        </div>
                    </div>
                    <div id="form-order" class="content order nice-scroll-right">
                        <div class="back" data-back><img src="images/arrow-left.png" alt=""> Назад</div>
                        <h3>Международный военно-музыкальный фестиваль "Спасская башня 2018"</h3>
                        <p class="where"><span class="event-date"></span> | Москва, Красная площадь</p>
                        <div class="top">
                            <img src=" <?php echo e(url('/images/checkout-image.jpg')); ?>" alt="Спасская башня 2018" title="Спасская башня 2018">
                            <div class="your-choose-table">
                                <div class="row name-step">
                                    <div class="name">Ваш заказ:</div>
                                </div>
                                <div class="wrapper-top-table">
                                    <table>
                                        <thead>
                                        <tr>
                                            <td>№</td>
                                            <td>Сектор</td>
                                            <td>Ряд</td>
                                            <td>Место</td>
                                            <td>Цена (<strong>₽</strong>)</td>
                                            <td><a href=""><img src="images/icon-remove.png" alt=""></a></td>
                                        </tr>
                                        </thead>
                                    </table>
                                </div>
                                <div class="nice-scroll">
                                    <div id="wrapper">
                                        <table id="form-order-ticket">
                                            <tbody>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="total-table right">
                                    <span>Итого:</span>
                                    <span class="price"><span class="number">0</span> ₽</span>
                                </div>
                            </div>
                        </div>
                        <div class="bottom">
                            <div class="left">
                                <div class="row name-step">
                                    <div class="name">Контактные данные:</div>
                                </div>
                                <div class="grid form">
                                    <div class="field block-12">
                                        <input name="form_order_field_name" type="text" placeholder="Имя" required="required">
                                        <div class="error-field" id="error_field_name"></div>
                                    </div>
                                    <div class="field block-6">
                                        <input name="form_order_field_phone" type="text" data-inputmask="'mask': '+7 (999) 999 99 99', 'placeholder': '+7 (---) --- -- --'" required="required">
                                        <div class="error-field" id="error_field_phone"></div>
                                    </div>
                                    <div class="field block-6">
                                        <input name="form_order_field_email" type="email" placeholder="E-mail">
                                        <div class="error-field" id="error_field_email"></div>
                                    </div>
                                    <div class="field block-12 hide-if-card">
                                        <input name="form_order_field_address" type="text" placeholder="Адрес доставки">
                                        <div class="error-field" id="error_field_address"></div>
                                    </div>
                                    <div class="field block-12">
                                        <textarea name="form_order_field_comment" placeholder="Комментарий"></textarea>
                                        <div class="error-field" id="error_field_comment"></div>
                                    </div>
                                    <div class="block-12">
                                        <p><span>*</span> Поля обязательные для заполнения</p>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="row name-step">
                                    <div class="name">Способы оплаты:</div>
                                </div>
                                <div class="checkboxes">
                                    <label>
                                        <input type="radio" name="form_order_field_payment" value="2" checked>
                                        <span class="name">Наличными курьеру</span>
                                        <span>Курьер подъедет в удобное для Вас время, предварительно предупредив по телефону. Оплата только наличными.</span>
                                    </label>
                                    <label>
                                        <input type="radio" name="form_order_field_payment" value="1" id="pay-card">
                                        <span class="name">Картой VISA / MASTERCARD</span>
                                        <span>После оплаты билеты будут отправлены на ваш e-mail</span>
                                        <img src="/images/payment-final-2.png">
                                    </label>
                                    <div class="error-field" id="error_field_payment"></div>
                                    <input id="form_order_field_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                    <div class="btn buy" id="form-order-button">купить билет</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="info-block" data-info-block="how-give">
                        <div class="header">
                            <h2>Как заказать</h2>
                            <img src="images/icon-close-modal.svg" alt="" class="close_info">
                        </div>
                        <div class="info-content">
                            <div class="wrap">
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                    <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                    <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                    <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="btn-back"><img src="/images/arrow-left.png" alt="">Назад</div>
                        </div>
                    </div>
                    <div class="info-block" data-info-block="sale">
                        <div class="header">
                            <h2>Оплата</h2>
                            <img src="images/icon-close-modal.svg" alt="" class="close_info">
                        </div>
                        <div class="info-content">
                            <div class="wrap">
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                    <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                    <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                    <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="btn-back"><img src="/images/arrow-left.png" alt="Назад" title="Назад">Назад</div>
                        </div>
                    </div>
                    <div class="info-block" data-info-block="contact">
                        <div class="header">
                            <h2>Контакты</h2>
                            <img src="/images/icon-close-modal.svg" alt="" class="close_info">
                        </div>
                        <div class="info-content">
                            <div class="wrap">
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                    <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                    <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                    <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="btn-back"><img src="/images/arrow-left.png" alt="">Назад</div>
                        </div>
                    </div>
                </div>
                <div class="footer-menu">
                    <ul class="left">
                        <li><a href="#" data-show-block="how-give">Как заказать?</a></li>
                        <li><a href="#" data-show-block="sale">Оплата</a></li>
                        <li><a href="#" data-show-block="contact">Контакты</a></li>
                    </ul>
                    <div class="right phone">
                        <a href="tel:+74951505802">+7 (495) 150-58-02</a>
                    </div>
                </div>
                <div class="message">
                    <div class="text" data-message="2">
                        <p>Вы действительно желаете<br>закончить покупку билетов?</p>
                        <div class="btn buy white" data-close-modal>Выйти</div>
                        <div class="btn buy" data-close-message>Продолжить покупку</div>
                    </div>
                    <div class="text" data-message="3">
                        <p>Вы действительно желаете<br>очистить заказ?</p>
                        <div class="btn buy white" data-clear-cart>Очистить</div>
                        <div class="btn buy" data-close-message>Закрыть окно</div>
                    </div>
                    <div class="text" data-message="ticket-delete">
                        <p>Вы действительно желаете<br>удалить билет?</p>
                        <div class="btn buy white" data-ticket-delete>Удалить</div>
                        <div class="btn buy" data-close-message>Закрыть окно</div>
                    </div>
                    <div class="overlay"></div>
                </div>
            </div>
            <div class="overlay"></div>
        </div>

        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal-participants modal-tickets" data-modal="participant-<?php echo e($participant['id']); ?>">
            <div class="inner">
                <div class="wrap-content">
                    <img src="<?php echo e(url('/images/icon-close.png')); ?>" alt="Закрыть" title="Закрыть" class="close">
                    <div class="content show">
                        <h3><?php echo e($participant['title']); ?></h3>
                        <div class="info nice-scroll-right">
                            <div class="image"><img src="<?php echo e($participant['image_large']); ?>" alt="<?php echo e($participant['title']); ?>" title="<?php echo e($participant['title']); ?>"></div>
                            <div class="country">
                                <div class="flag"><img src="<?php echo e(url('/images/participants/flag_' . $participant['country']['code'] . '.jpg')); ?>" alt="<?php echo e($participant['country']['name']); ?>" title="<?php echo e($participant['country']['name']); ?>"></div>
                                <div class="caption">Страна - <span><?php echo e($participant['country']['name']); ?></span></div>
                            </div>
                            <div class="text"><?php echo $participant['text']; ?></div>
                            <?php if($participant['images']): ?>
                                <div class="photos">
                                    <div class="title">Фото<div class="slider-buttons"><div class="slider-buttons-left">&nbsp;</div><div class="slider-buttons-right">&nbsp;</div></div></div>
                                    <div class="items">
                                        <div class="swiper-container">
                                            <div class="swiper-wrapper">
                                                <?php $__currentLoopData = $participant['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="swiper-slide"><a href="<?php echo e($image['original']); ?>" data-fancybox="gallery_<?php echo e($participant['id']); ?>"><img src="<?php echo e($image['thumb']); ?>"></a></div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="overlay"></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
    <div class="button-up"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>