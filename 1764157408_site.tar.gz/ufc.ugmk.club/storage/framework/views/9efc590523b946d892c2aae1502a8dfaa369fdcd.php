<div class="row">
	<div class="col-xl-6 col-lg-12">

        <div class="form-group">
            <button type="button" class="switch-button btn btn-toggle btn-primary<?php echo e(isset($scheme) && $scheme->status ? ' active' : ''); ?>" data-toggle="button" aria-pressed="true" data-switch_hidden_id="field_scheme_status">
                <span class="handle"></span>
            </button>
            <?php echo e(Form::hidden('status', null, ['class' => 'switch-hidden', 'data-switch_hidden_id' => 'field_scheme_status'])); ?>

        </div>

		<div class="form-group<?php echo e(empty($errors->get('name')) ? '' : ' has-error'); ?>">
			<?php echo Form::label('name', 'Название схемы площадки <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

        <div class="form-group<?php echo e(empty($errors->get('location_id')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('location_id', 'Локация <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::select('location_id', $locations, null, ['class' => 'form-control select-select2'])); ?>

            <?php $__currentLoopData = $errors->get('location_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>



	</div>
</div>