<div class="row">
	<div class="col-xl-6 col-lg-12">

        <div class="form-group">
            <button type="button" class="switch-button btn btn-toggle btn-primary<?php echo e(isset($participant) && $participant->status ? ' active' : ''); ?>" data-toggle="button" aria-pressed="true" data-switch_hidden_id="field_participant_status">
                <span class="handle"></span>
            </button>
            <?php echo e(Form::hidden('status', null, ['class' => 'switch-hidden', 'data-switch_hidden_id' => 'field_participant_status'])); ?>

        </div>

		<div class="form-group<?php echo e(empty($errors->get('name')) ? '' : ' has-error'); ?>">
			<?php echo Form::label('name', 'Название участника <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

        <div class="form-group<?php echo e(empty($errors->get('text')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('text', 'Текст', [], false); ?>

            <?php echo e(Form::textarea('text', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('text'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('country')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('country', 'Страна <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::select('country', $countries, null, ['class' => 'form-control select-select2'])); ?>

            <?php $__currentLoopData = $errors->get('country'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('image')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('image', 'Картинка', [], false); ?>

            <div class="file-image-button">
                <label>
                    <?php echo e(Form::file('image', null, ['class' => 'form-control'])); ?>

                    <div class="btn btn-info">Выбрать файл</div>
                </label>
                <div class="file-image-button-image">
                    <?php if($participant_image): ?>
                        <img src="<?php echo e($participant_image); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('image_large')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('image_large', 'Картинка (большая)', [], false); ?>

            <div class="file-image-button">
                <label>
                    <?php echo e(Form::file('image_large', null, ['class' => 'form-control'])); ?>

                    <div class="btn btn-info">Выбрать файл</div>
                </label>
                <div class="file-image-button-image">
                    <?php if($participant_image_large): ?>
                        <img src="<?php echo e($participant_image_large); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('sort')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('sort', 'Сортировка', [], false); ?>

            <?php echo e(Form::text('sort', $sort ? $sort : 0, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('sort'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
	</div>
</div>