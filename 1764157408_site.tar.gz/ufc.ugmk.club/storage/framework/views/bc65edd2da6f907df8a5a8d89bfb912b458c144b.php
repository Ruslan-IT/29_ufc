<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="../../../images/favicon.ico">

    <title>Lion Admin - Log in </title>
    <!-- Bootstrap 4.0-->
    <link rel="stylesheet" href="<?php echo e(asset('lion-admin/assets/vendor_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <!-- Bootstrap extend-->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/bootstrap-extend.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/master_style.css')); ?>">
    <!-- Lion_admin skins -->
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/_all-skins.css')); ?>">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="hold-transition login-page">

        <?php echo $__env->yieldContent('content'); ?>

<!-- jQuery 3 -->
<script src="<?php echo e(asset('Documentation/assets/vendor_components/jquery/dist/jquery.min.js')); ?>"></script>

<!-- popper -->
<script src="<?php echo e(asset('lion-admin/assets/vendor_components/popper/dist/popper.min.js')); ?>"></script>

<!-- Bootstrap 4.0-->
<script src="<?php echo e(asset('lion-admin/assets/vendor_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>


</body>
</html>
