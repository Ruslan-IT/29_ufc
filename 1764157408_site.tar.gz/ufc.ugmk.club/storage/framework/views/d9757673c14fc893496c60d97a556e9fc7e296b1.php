<?php $__env->startSection('content'); ?>
    <div class="menu-fixed no_mobile">
        <div class="wrapper">
            <img class="logo-menu" src="images/logo-in-menu.png" alt="logo Black Star">
            <nav id="menu-fixed">
                <ul>
                    <li data-menuanchor="home" class="no_mobile"><a href="#home">Главная</a></li>
                    <li data-menuanchor="concert" class="no_mobile"><a href="#concert">концерт</a></li>
                    <li data-menuanchor="place" class="no_mobile"><a href="#place">Площадка</a></li>
                    <li data-menuanchor="media" class="no_mobile"><a href="#media">Клипы</a></li>
                    <li data-menuanchor="info" class="no_mobile"><a href="#info">Об Артисте</a></li>
                    <li data-menuanchor="lastpage"><a href="#lastpage">Будь в курсе</a></li>
                </ul>
            </nav>
            <div class="right">
                <a class="phone" href="tel:+74951505802">+7 (495) 150-58-02</a>
                <a class="btn buy" href="#" data-open-modal="1">Купить билет</a>
            </div>
        </div>
    </div>
    <div class="wrapper mobile">
        <div class="section lastpage mobile">
            <a class="phone" href="tel:+74951505802">+7 (495) 150-58-02</a>
            <div class="inner">
                <div class="wrapper">
                    <div class="left">
                        <div class="center">
                            <h3>Григорий</h3>
                            <h1>Лепс</h1>
                        </div>
                        <div class="bottom">
                            <h2>16 Июля 2018 <span>|</span> 20:00</h2>
                            <p>Трибьют концерт В день рождения</p>
                            <p>Спорткомплекс “олимпийский”, москва</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-down">
                <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
            </div>
        </div>
    </div>
    <div id="fullpage">
        <section class="section home" data-anchor="home">
            <div class="wrapper">
                <div class="right">
                    <h2>16 Июля 2018 <span>|</span> 20:00</h2>
                    <div class="center">
                        <h3>Григорий</h3>
                        <h1>Лепс</h1>
                    </div>
                    <p>Трибьют концерт В день рождения</p>
                    <p>Спорткомплекс “олимпийский”, москва</p>
                    <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
                </div>
            </div>
            <div class="scroll-down">
                <a class="scroll-link" href="#video-sect">
                    <div class="mouse">
                        <span class="mouse__wheel"></span>
                    </div>
                </a>
            </div>
        </section>
        <section class="section concert" data-anchor="concert">
            <div class="inner">
                <div class="wrapper">
                    <img src="images/img-leps-2.jpg" alt="">
                    <div class="text">
                        <p>Уникальный и неповторимый концерт пройдет 16 июля этого года в легендарном спорткомплексе "Олимпийский". На сцену главного зала столицы нашей страны выйдет Григорий Лепс и его друзья-артисты. Достать билеты на концерт Григория Лепса сложно всегда. Но в этот раз это будет сделать особенно непросто, ведь помимо главного человека вечера, в "Олимпийском" песни Григория Лепса будет исполнять целая россыпь отечественных звезд - Валерий Меладзе, Тимати, Эмин, Диана Арбенина, Полина Гагарина, Светлана Лобода, Филипп Киркоров, группа "Руки вверх!", Стас Михайлов и другие исполнители, которые сами спродюсировали такой необычный концерт. Все они соберутся, чтобы поздравить Григория Лепса с днем рождения. Музыканту и певцу исполнится 56 лет.</p>
                        <p>Вы можете заранее обеспечить свое присутствие на данном празднике музыки. На нашем сайте вы уже сейчас можете купить билеты на концерт Григория Лепса. Известно, что несмотря на огромную вместимость спорткомплекса "Олимпийский", купить билеты на проводимые там мероприятия бывает весьма непросто, все самое лакомое достается перекупщикам, которые оккупируют кассы сразу после их открытия и не дают простым людям взять билет. Зайдя на наш сайт, вам не придется проводить свое время в бесполезном стоянии в очереди у касс. Вы можете не выходя из дома уже сегодня заказать у нас билеты на концерт Григория Лепса 16 июля. Торопитесь, билеты на Лепса расходятся как горячие пирожки.</p>
                        <p>Артисты начали заранее готовиться к концерту в честь Григория Лепса. Они тщательно выбирали песню из репертуара маэстро, которая ближе им по духу. Сам именинник не знает, кто из его друзей споет ту или иную композицию, это станет для него сюрпризом. Такой концерт станет первым подобным мероприятием в данном формате, раскрывающим песни Григория Лепса в неожиданном прочтении. Конечно же, и сам именинник выступит на сцене, исполнив свои незабываемые хиты. А, значит, гостей концерта ждет океан драйва, качественной музыки и улетного настроения. Скучно на концертах Лепса не бывает никогда, в этот же раз намечается особая атмосфера. Пропустить такое событие в Москве невозможно. Спешите купить билеты!</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="section place" data-anchor="place">
            <div class="inner">
                <div class="column">
                    <div class="top">
                        <img src="images/logo-stadium.png" alt="">
                        <div class="when">16 Июля | 20:00</div>
                        <div class="where">
                            Спортивный комплекс олимпийский
                        </div>
                        <div class="addres">Россия, <span>г.</span> Москва, Олимпийский <span>пр.,</span> 16, <span>c.</span>1,2</div>
                    </div>
                    <div class="bottom">
                        <div id="map">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section media" data-anchor="media">
            <div class="inner">
                <div class="row">
                    <div class="block-left">
                        <a class="block" data-fancybox href="https://www.youtube.com/watch?v=PDm9HfLCagM">
                            <div class="info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70.22" height="80.04" viewBox="0 0 70.22 80.04">
                                    <path class="cls-1" d="M1319.03,4219.65L1249,4259.86l-0.19-80.01Z" transform="translate(-1248.81 -4179.84)" />
                                </svg>
                                <div class="text">
                                    <div class="auther">григорий лепс Ft. ани лорак</div>
                                    <div class="name">зеркала</div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="block-right">
                        <a class="block first" data-fancybox href="https://www.youtube.com/watch?v=jRMAMkqTTns">
                            <div class="info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70.22" height="80.04" viewBox="0 0 70.22 80.04">
                                    <path class="cls-1" d="M1319.03,4219.65L1249,4259.86l-0.19-80.01Z" transform="translate(-1248.81 -4179.84)" />
                                </svg>
                                <div class="text">
                                    <div class="auther">григорий лепс Ft. green gray</div>
                                    <div class="name">Бабосы Боссам</div>
                                </div>
                            </div>
                        </a>
                        <a class="block second" data-fancybox href="https://www.youtube.com/watch?v=dZkCiBvbzw8">
                            <div class="info">
                                <svg xmlns="http://www.w3.org/2000/svg" width="70.22" height="80.04" viewBox="0 0 70.22 80.04">
                                    <path class="cls-1" d="M1319.03,4219.65L1249,4259.86l-0.19-80.01Z" transform="translate(-1248.81 -4179.84)" />
                                </svg>
                                <div class="text">
                                    <div class="auther">григорий лепс Ft. Тимати</div>
                                    <div class="name">дай мне уйти</div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section class="section info" data-anchor="info">
            <div class="inner">
                <img src="images/leps-3.png" alt="">
                <div class="wrapper">
                    <div class="text">
                        <h2><span>григорий</span> лепс</h2>
                        <p>Хорошая музыка способна дотронуться до нашей души и пробудить самые лучшие чувства. Музыка Григория Лепса задевает за живое, превращая обычное слияние нот в душевную симфонию. Он покорил миллионы благодаря уникальному тембру голоса, своеобразной манере исполнения и сильному характеру, который чувствуется в каждой ноте.</p>
                        <p>Великого певца нам подарил прекрасный город Сочи в 1962 году. Родился Григорий в семье простых рабочих и впитал в себя лучшие качества трудолюбия и целеустремлённости, которые очень помогли ему в дальнейшем. Свою первую работу он получил еще вовремя обучения в музыкальном училище, представив свой талант перед публикой курортного города в ночных заведениях. Желание карьерного роста ведёт Лепса в столицу, и вот Москва распахивает двери перед молодым и перспективным исполнителем, который уже накопил не только опыт вокального мастерства, но и усталость и стресс, что как магнитом привлекло к Григорию проблемы с алкоголем. В скором будущем они еще дадут о себе знать.</p>
                        <p>Упорный труд сводит Григория с Виталием Маншиным, и благодаря ему в 1995 году Россия получает первую пластинку «Храни вас Бог». Она становится трамплином в успешное будущее, которое почти оборвалось вместе с жизнью певца из-за алкоголя. Находясь на краю смертельной пропасти, врачи помогли молодому человеку выкарабкаться и начать новый этап в жизни, который разительно отличался от пагубного периода.</p>
                        <p>Вернувшись в водоворот активной работы, Григорий Лепс выпускает ряд пластинок, из года в год, покоряя всё большую аудиторию. В период с 1999 мы получаем возможность наслаждаться альбомами "Целая жизнь", «Спасибо, люди», «На струнах дождя», «Парус», «Избранное», «Лабиринт», а так же получаем легендарные клипы и окончательное формирование стиля певца, который сейчас является одним из самых узнаваемых на отечественной эстраде.</p>
                        <p>С 2006-го года у певца начинается новый виток в карьере, и помимо стабильного выпуска альбомов, каждый из которых становится хитом, мы получаем уникальные и весьма неожиданные дуэты. Лепс выпускает совместные песни со Стасом Пьехой, Валерием Меладзе, Тимати, Ани Лорак, Ириной Алегровой, Александром Розенбаумом и другими мастодонтами современной эстрады.</p>
                        <p>Несмотря на проблемы с алкоголем сложный график работы и вытекающие трудности со здоровьем, певец всегда оставался хорошим отцом для своих детей от первого и третьего брака (второй брак не принёс певцу наследников). Сейчас он счастливо женат на девушке Анне, которую встретил в Москве.</p>
                        <p>Григорий Лепс продолжает строить успешную карьеру, давать концерты по всему миру и оставаться одним из самых востребованных артистов, несмотря на то, что свой след в истории он уже оставил, а его песни наизусть знают несколько поколений. Одним из последних достижений артиста стал установленный рекорд по количеству концертов, к этому статусу его привели 5 аншлаговых концертов и новый альбом «ТыЧегоТакойСерьезный».</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="section lastpage" data-anchor="lastpage">
            <div class="inner">
                <img src="images/leps-4.png" alt="">
                <div class="wrapper">
                    <div class="left">
                        <h2>16 Июля 2018 <span>|</span> 20:00</h2>
                        <div class="center">
                            <h3>Григорий</h3>
                            <h1>Лепс</h1>
                        </div>
                        <p>Трибьют концерт В день рождения</p>
                        <p>Спорткомплекс “олимпийский”, москва</p>
                        <a href="" class="btn buy" data-open-modal="1">Купить билет</a>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <div class="modal-tickets" data-modal="1">
        <div class="inner">
            <div class="wrap-content">
                <img src="images/icon-close-modal.svg" alt="" class="close">
                <div class="content maket show" data-content="1">
                    <h3><span>Григорий Лепс</span> <i>|</i> Трибьют концерт в день рождения</h3>
                    <p class="where">16 июля 2018, в 20:00 | Москва, СК “Олимпийский”</p>
                    <div class="map-block">
                        <?php if($colors): ?>
                            <div class="map-prices">
                                <span class="caption">Фильтр по цене:</span>
                                <ul>
                                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li p-min="<?php echo e($color['from']); ?>" p-max="<?php echo e($color['to']); ?>">
                                            <p class="price"><?php echo e($color['title']); ?></p>
                                            <div class="line" style="background:#<?php echo e($color['color']); ?>"></div>
                                            <div class="tooltip"><?php echo e($color['label']); ?></div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="map-scheme">
                            <div class="tooltip" data-for="place">
                                <p class="about-price"><span></span> ₽</p>
                                <p class="about-sector"></p>
                                <div class="block-right">
                                    <span class="about-row">
                                        <span>ряд</span>
                                        <span class="number"></span>
                                    </span>,
                                    <span class="about-place">
                                        <span>место</span>
                                        <span class="number"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="tooltip" data-for="sector">
                                <p class="name"></p>
                                <div class="about-price"><span class="number"></span></div>
                                <div class="free-place">Свободных мест: <span class="number"></span></div>
                            </div>
                            <div class="hover-place"></div>
                            <svg id="svg-map" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0" y="0">
                                <g id="svg-map-container">
                                    <filter id="dropShadow" x="-100%" y="-100%" width="300%" height="300%">
                                        <feDropShadow stdDeviation="3" flood-color="#444" flood-opacity=".5" dx="0" dy="0"></feDropShadow>
                                    </filter>
                                    <g class="sh-decor">
                                        <image href="<?php echo e(url('images/scheme_decor.png')); ?>" x="0" y="1.5" height="3313px" width="7846px"/>
                                    </g>

                                    <?php $__currentLoopData = $svg_conf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <g class="sh-sector" sn="<?php echo e($sector['title']); ?>" sid="<?php echo e($sector['id']); ?>" fp="<?php echo e(count($sector['places'])); ?>" pc="<?php echo e($sector['price_min'] == $sector['price_max'] ? $sector['price_min'] : $sector['price_min'] . ' - ' . $sector['price_max']); ?> ₽">
                                            <?php $__currentLoopData = $sector['places']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <circle class="pa" cx="<?php echo e($place['x']); ?>" cy="<?php echo e($place['y']); ?>" r="<?php echo e($sector['place_radius']); ?>"<?php echo e($sector['place_radius_max'] ? ' mx=' . $sector['place_radius_max'] : ''); ?> pp="<?php echo e($place['place']); ?>" pr="<?php echo e($place['row']); ?>" ps="<?php echo e($place['price']); ?>" style="fill: #<?php echo e($place['color']); ?>; stroke: #<?php echo e($place['color']); ?>" />
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <path class="sh-path" d="<?php echo e($sector['path']); ?>"/>
                                        </g>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <g class="sh-actived-places"></g>
                                </g>
                            </svg>
                            <div class="controls">
                                <button class="change-zoom svg-map-button" type="button" data-zoom_type="+"><img src="images/icon-controll-plus.png"></button>
                                <button class="change-zoom svg-map-button disabled" type="button" data-zoom_type="-"><img src="images/icon-controll-minus.png"></button>
                                <button class="disabled" id="reset" type="button">
                                    <img src="images/icon-controll-home.png" alt="">
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="panel-controll">
                        <div class="row">
                            <div class="clear">
                                <span><img src="images/trash-grey.svg" alt=""></span> очистить заказ
                            </div>
                            <div class="your-choose">
                                <span>Вы выбрали: </span>
                                <span class="choosed">
                                    <span class="button-open-popup">
                                        <span class="number">0</span> билета <img src="images/arrow-choose.png" alt="">
                                    </span>
                                <div class="wrap-popup">
                                    <div class="tickets popup">
                                        <h3>ваш заказ</h3>
                                        <ul class="list-tickets nice-scroll-right">
                                        </ul>
                                    </div>
                                </div>
                                </span>
                            </div>
                            <div class="total">
                                <span>Итого (<strong>₽</strong>): </span>
                                <span class="price">0</span>
                            </div>
                            <div class="btn buy mobile">
                                Купить 
                                <span class="number billets"></span> 
                                билета за 
                                <span class="number price"></span> ₽</div>
                            <div class="btn buy">оформить заказ</div>
                        </div>
                    </div>
                </div>
                <div id="form-order" class="content order nice-scroll-right">
                    <div class="back" data-back><img src="images/arrow-left.png" alt=""> Назад</div>
                    <div class="stiker-top"></div>
                    <div class="top">
                        <div class="stiker">
                            <p class="top"><span>Григорий Лепс</span><br>Трибьют концерт<br>в день рождения</p>
                            <p>16 июля 2018, в 20:00<br> Москва, СК “Олимпийский”</p>
                            <div class="btn buy" data-back>добавить билет</div>
                        </div>
                        <div class="your-choose-table">
                            <div class="row name-step">
                                <div class="number">1</div>
                                <div class="name">Ваш заказ:</div>
                            </div>
                            <div class="wrapper-top-table">
                                <table>
                                    <thead>
                                    <tr>
                                        <td>№</td>
                                        <td>Сектор</td>
                                        <td>Ряд</td>
                                        <td>Место</td>
                                        <td>Цена (<strong>₽</strong>)</td>
                                        <td><a href=""><img src="images/icon-remove.png" alt=""></a></td>
                                    </tr>
                                    </thead>
                                </table>
                            </div>
                            <div class="nice-scroll">
                                <div id="wrapper">
                                    <table id="form-order-ticket">
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="total-table right">
                                <span>Итого:</span>
                                <span class="price"><span class="number">0</span> ₽</span>
                            </div>
                        </div>
                    </div>
                    <div class="bottom">
                        <div class="left">
                            <div class="row name-step">
                                <div class="number">2</div>
                                <div class="name">Контактные данные:</div>
                            </div>
                            <div class="grid form">
                                <div class="field block-12">
                                    <input name="form_order_field_name" type="text" placeholder="Имя" required="required">
                                    <div class="error-field" id="error_field_name"></div>
                                </div>
                                <div class="field block-6">
                                    <input name="form_order_field_phone" type="text" data-inputmask="'mask': '+7 (999) 999 99 99', 'placeholder': '+7 (---) --- -- --'" required="required">
                                    <div class="error-field" id="error_field_phone"></div>
                                </div>
                                <div class="field block-6">
                                    <input name="form_order_field_email" type="email" placeholder="E-mail">
                                    <div class="error-field" id="error_field_email"></div>
                                </div>
                                <div class="field block-12 hide-if-card">
                                    <input name="form_order_field_address" type="text" placeholder="Адрес доставки">
                                    <div class="error-field" id="error_field_address"></div>
                                </div>
                                <div class="field block-12">
                                    <textarea name="form_order_field_comment" placeholder="Комментарий"></textarea>
                                    <div class="error-field" id="error_field_comment"></div>
                                </div>
                                <div class="block-12">
                                    <p><span>*</span> Поля обязательные для заполнения</p>
                                </div>
                            </div>
                        </div>
                        <div class="right">
                            <div class="row name-step">
                                <div class="number">3</div>
                                <div class="name">Способы оплаты:</div>
                            </div>
                            <div class="checkboxes">
                                <label>
                                    <input type="radio" name="form_order_field_payment" value="2" checked>
                                    <span class="name">Наличными курьеру</span>
                                    <span>Курьер подъедет в удобное для Вас время, предварительно предупредив по телефону. Оплата только наличными.</span>
                                </label>
                                <label>
                                    <input type="radio" name="form_order_field_payment" value="1" id="pay-card">
                                    <span class="name">Картой VISA / MASTERCARD</span>
                                    <span>После оплаты билеты будут отправлены на ваш e-mail</span>
                                    <img src="/images/payment-final-2.png">
                                </label>
                                <div class="error-field" id="error_field_payment"></div>
                                <input id="form_order_field_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                <div class="btn buy" id="form-order-button">купить билет</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="info-block" data-info-block="how-give">
                    <div class="header">
                        <h2>Как заказать</h2>
                        <img src="images/icon-close-modal.svg" alt="" class="close_info">
                    </div>
                    <div class="info-content">
                        <div class="wrap">
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer">
                        <div class="btn-back"><img src="/images/arrow-left.png" alt="">Назад</div>
                    </div>
                </div>
                <div class="info-block" data-info-block="sale">
                    <div class="header">
                        <h2>Оплата</h2>
                        <img src="images/icon-close-modal.svg" alt="" class="close_info">
                    </div>
                    <div class="info-content">
                        <div class="wrap">
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer">
                        <div class="btn-back"><img src="/images/arrow-left.png" alt="Назад" title="Назад">Назад</div>
                    </div>
                </div>
                <div class="info-block" data-info-block="contact">
                    <div class="header">
                        <h2>Контакты</h2>
                        <img src="/images/icon-close-modal.svg" alt="" class="close_info">
                    </div>
                    <div class="info-content">
                        <div class="wrap">
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                            <div class="how_to_block">
                                <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer">
                        <div class="btn-back"><img src="/images/arrow-left.png" alt="">Назад</div>
                    </div>
                </div>
            </div>
            <div class="footer-menu">
                <ul class="left">
                    <li><a href="#" data-show-block="how-give">Как заказать?</a></li>
                    <li><a href="#" data-show-block="sale">Оплата</a></li>
                    <li><a href="#" data-show-block="contact">Контакты</a></li>
                </ul>
                <div class="right phone">
                    <a href="tel:+74951505802">+7 (495) 150-58-02</a>
                </div>
            </div>
            <div class="message">
                <div class="text" data-message="1">
                    <p>Спасибо за покупку! Ваш заказ <a href="">№ 163</a> успешно оформлен!</p>
                    <p>В ближайшее время с Вами свяжется менеджер для уточнения деталей.</p>
                    <p>По всем вопросам костельно заказа, обращайтесь по телефону:</p>
                    <p><a href="">+7 495 222 20 92</a></p>
                </div>
                <div class="text" data-message="2">
                    <p>Вы действительно желаете<br>закончить покупку билетов?</p>
                    <div class="btn buy white" data-close-modal>Выйти</div>
                    <div class="btn buy" data-close-message>Продолжить покупку</div>
                </div>
                <div class="text" data-message="3">
                    <p>Вы действительно желаете<br>очистить заказ?</p>
                    <div class="btn buy white" data-clear-cart>Очистить</div>
                    <div class="btn buy" data-close-message>Закрыть окно</div>
                </div>
                <div class="text" data-message="ticket-delete">
                    <p>Вы действительно желаете<br>удалить билет?</p>
                    <div class="btn buy white" data-ticket-delete>Удалить</div>
                    <div class="btn buy" data-close-message>Закрыть окно</div>
                </div>
                <div class="overlay"></div>
            </div>
        </div>
        <div class="overlay"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>