<?php $__env->startSection('content'); ?>
    <div class="menu-fixed fixed<?php echo e(($message['status'] != 0) ? ' single-page' : ''); ?>">
        <div class="wrapper">
            <div class="menu-button"></div>
            <img class="logo-menu" src="images/logo.png" alt="UFC Fight Night Moscow" title="UFC Fight Night Moscow">
            <nav id="menu-fixed">
                <ul>
                    <li data-menuanchor="home"><a href="#home">Главная</a></li>
                    <li data-menuanchor="video"><a href="#video">Видео</a></li>
                    <li data-menuanchor="map"><a href="#map">Площадка</a></li>
                    <li data-menuanchor="vip"><a href="#vip">VIP билеты</a></li>
                    <li data-menuanchor="buy"><a href="#buy">Будь в курсе</a></li>
                </ul>
            </nav>
            <div class="right">
                <a class="phone" href="tel:+74951505802">+7 (495) 150-58-02</a>
                <?php if($message['status'] == 0): ?>
                    <a class="btn btn-style buy" href="#" data-open-modal="1">Купить билет</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="menu-mobile">
        <div class="menu-mobile-header">
            <div class="menu-close">
                <span>&nbsp;</span>
                <div class="line">&nbsp;</div>
            </div>
            <img class="logo-menu" src="images/logo.png" alt="UFC Fight Night Moscow" title="UFC Fight Night Moscow">
        </div>
        <ul class="menu-items">
            <li data-menuanchor="home"><a href="#home">Главная</a></li>
            <li data-menuanchor="video"><a href="#video">Видео</a></li>
            <li data-menuanchor="map"><a href="#map">Площадка</a></li>
            <li data-menuanchor="vip"><a href="#vip">VIP билеты</a></li>
            <li data-menuanchor="buy"><a href="#buy">Будь в курсе</a></li>
        </ul>
        <a class="menu-mobile-buy" href="#" data-open-modal="1">Купить билет</a>
    </div>

    <?php if($message['status'] != 0): ?>
        <div class="page single-page">
            <div class="message">
                <?php if($message['status'] == 1): ?>
                    <h3>Ваш заказ оформлен!</h3>
                    <p><strong><?php echo e($message['name']); ?>, спасибо за покупку!</strong></p>
                    <p>Ваш заказ # <?php echo e($message['order']); ?></p>
                    <p>В ближайшее время с Вами свяжется менеджер для уточнения деталей. По всем вопросам, касательно заказа обращайтесь по телефону:</p>
                    <p><strong>+7 (495) 150-58-02</strong></p>
                <?php endif; ?>
                <?php if($message['status'] == 2): ?>
                    <h3>Ваш заказ не оформлен!</h3>
                    <p><strong><?php echo e($message['name']); ?>, повторите покупку!</strong></p>
                    <p>По всем вопросам, касательно заказа обращайтесь по телефону:</p>
                    <p><strong>+7 (495) 150-58-02</strong></p>
                <?php endif; ?>
                <a class="btn" href="<?php echo e(url('/')); ?>">На главную</a>
            </div>
        </div>
    <?php else: ?>

        <div class="fullpage-wrap">
            <div id="fullpage">
                <section class="section home" data-anchor="home">
                    <img class="men" src="<?php echo e(url('/images/men.png')); ?>" alt="UFC Fight Night Moscow" title="UFC Fight Night Moscow">
                    <div class="wrapper">
                        <div class="inner">
                            <div class="caption">
                                <h1>Впервые <span class="type-1">в Москве</span> турнир <div class="type-2"><span>UFC</span><span class="line"></span></div></h1>
                                <h3>спортивный комплекс «олимпийский»</h3>
                                <div class="info">
                                    <div class="date">15 сентября 2018 в 17:30</div>
                                    <a href="#" class="btn btn-style buy" data-open-modal="1">Купить билеты</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="scroll-down">
                        <a class="scroll-link" href="#video-sect">
                            <div class="mouse">
                                <span class="mouse__wheel"></span>
                            </div>
                        </a>
                    </div>
                </section>
                <section class="section media" data-anchor="video">
                    <div class="inner">
                        <div class="row">
                            <div class="block-left">
                                <a class="block" data-fancybox href="https://www.youtube.com/watch?v=46M01aonbv8">
                                    <img src="<?php echo e(url('/images/icon-play.png')); ?>" alt="Воспроизвести видео" title="Воспроизвести видео">
                                    <div class="text"><div class="auther">The Ultimate Fighter 27 Finale</div></div>
                                </a>
                            </div>
                            <div class="block-right">
                                <a class="block first" data-fancybox href="https://www.youtube.com/watch?v=S4kw-g6ORAE">
                                    <img src="<?php echo e(url('/images/icon-play.png')); ?>" alt="Воспроизвести видео" title="Воспроизвести видео">
                                    <div class="text"><div class="auther">Miocic vs. Cormier</div></div>
                                </a>
                                <a class="block second" data-fancybox href="https://www.youtube.com/watch?v=BwV5v2aJqaY">
                                    <img src="<?php echo e(url('/images/icon-play.png')); ?>" alt="Воспроизвести видео" title="Воспроизвести видео">
                                    <div class="text"><div class="auther">Dos Santos vs. Ivanov</div></div>
                                </a>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="section place" data-anchor="map">
                    <div class="inner">
                        <div class="column">
                            <div class="top">
                                <div class="when">15 сентября 2018 в 17:30</div>
                                <div class="where"><span>спортивный комплекс «олимпийский»</span></div>
                                <div class="addres">Россия, г. Москва,<br>Олимпийский проспект, 16. стр. 1,2.</div>
                            </div>
                            <div class="bottom">
                                <div id="contact-map"></div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="section info" data-anchor="vip">
                    <div class="inner">
                        <div class="wrapper">
                            <div class="block-buy">
                                <div class="vip-caption">&nbsp;</div>
                                <div class="vip-items">
                                    <div class="item">&nbsp;</div>
                                    <div class="item">&nbsp;</div>
                                    <div class="item">&nbsp;</div>
                                    <div class="item">&nbsp;</div>
                                    <div class="item">&nbsp;</div>
                                </div>
                                <a href="#" class="btn btn-style buy" data-open-modal="1">Купить VIP билеты</a>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="section home home-last" data-anchor="buy">
                    <img class="men" src="<?php echo e(url('/images/men-3.png')); ?>" alt="UFC Fight Night Moscow" title="UFC Fight Night Moscow">
                    <div class="wrapper">
                        <div class="inner">
                            <div class="caption">
                                <h1>Впервые <span class="type-1">в Москве</span> турнир <div class="type-2"><span>UFC</span><span class="line"></span></div></h1>
                                <h3>спортивный комплекс «олимпийский»</h3>
                                <div class="info">
                                    <div class="date">15 сентября 2018 в 17:30</div>
                                    <a href="#" class="btn btn-style buy" data-open-modal="1">Купить билеты</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>


        <div class="modal-tickets" data-modal="1">
            <div class="inner">
                <div class="wrap-content">
                    <img src="<?php echo e(url('/images/icon-close.png')); ?>" alt="Закрыть" title="Закрыть" class="close">
                    <div class="content maket show" data-content="1">
                        <h3>UFC Fight Night Moscow</h3>
                        <p class="where"><span class="event-date"></span> | Москва, СК "Олимпийский"</p>
                        <div class="map-block"></div>
                        <div class="panel-controll">
                            <div class="row">
                                <div class="clear">
                                    <span><img src="images/trash-grey.svg" alt=""></span> очистить заказ
                                </div>
                                <div class="your-choose">
                                    <span>Вы выбрали: </span>
                                    <span class="choosed">
                                        <span class="button-open-popup">
                                            <span class="number">0</span> билета <img src="images/arrow-choose.png" alt="">
                                        </span>
                                    <div class="wrap-popup">
                                        <div class="tickets popup">
                                            <h3>ваш заказ</h3>
                                            <ul class="list-tickets nice-scroll-right">
                                            </ul>
                                        </div>
                                    </div>
                                    </span>
                                </div>
                                <div class="total">
                                    <span>Итого (<strong>₽</strong>): </span>
                                    <span class="price">0</span>
                                </div>
                                <div class="btn buy mobile">
                                    Купить
                                    <span class="number billets"></span>
                                    билета за
                                    <span class="number price"></span> ₽</div>
                                <div class="btn buy">оформить заказ</div>
                            </div>
                        </div>
                    </div>
                    <div id="form-order" class="content order nice-scroll-right">
                        <div class="back" data-back><img src="images/arrow-left.png" alt=""> Назад</div>
                        <div class="stiker-top"></div>
                        <div class="top">
                            <div class="stiker">
                                <p class="top">UFC Fight Night<br>Moscow</p>
                                <p>15 сентября, 17:30<br> Москва, СК "Олимпийский"</p>
                                <div class="btn buy" data-back>добавить билет</div>
                            </div>
                            <div class="your-choose-table">
                                <div class="row name-step">
                                    <div class="number">1</div>
                                    <div class="name">Ваш заказ:</div>
                                </div>
                                <div class="wrapper-top-table">
                                    <table>
                                        <thead>
                                        <tr>
                                            <td>№</td>
                                            <td>Сектор</td>
                                            <td>Ряд</td>
                                            <td>Место</td>
                                            <td>Цена (<strong>₽</strong>)</td>
                                            <td><a href=""><img src="images/icon-remove.png" alt=""></a></td>
                                        </tr>
                                        </thead>
                                    </table>
                                </div>
                                <div class="nice-scroll">
                                    <div id="wrapper">
                                        <table id="form-order-ticket">
                                            <tbody>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="total-table right">
                                    <span>Итого:</span>
                                    <span class="price"><span class="number">0</span> ₽</span>
                                </div>
                            </div>
                        </div>
                        <div class="bottom">
                            <div class="left">
                                <div class="row name-step">
                                    <div class="number">2</div>
                                    <div class="name">Контактные данные:</div>
                                </div>
                                <div class="grid form">
                                    <div class="field block-12">
                                        <input name="form_order_field_name" type="text" placeholder="Имя" required="required">
                                        <div class="error-field" id="error_field_name"></div>
                                    </div>
                                    <div class="field block-6">
                                        <input name="form_order_field_phone" type="text" data-inputmask="'mask': '+7 (999) 999 99 99', 'placeholder': '+7 (---) --- -- --'" required="required">
                                        <div class="error-field" id="error_field_phone"></div>
                                    </div>
                                    <div class="field block-6">
                                        <input name="form_order_field_email" type="email" placeholder="E-mail">
                                        <div class="error-field" id="error_field_email"></div>
                                    </div>
                                    <div class="field block-12 hide-if-card">
                                        <input name="form_order_field_address" type="text" placeholder="Адрес доставки">
                                        <div class="error-field" id="error_field_address"></div>
                                    </div>
                                    <div class="field block-12">
                                        <textarea name="form_order_field_comment" placeholder="Комментарий"></textarea>
                                        <div class="error-field" id="error_field_comment"></div>
                                    </div>
                                    <div class="block-12">
                                        <p><span>*</span> Поля обязательные для заполнения</p>
                                    </div>
                                </div>
                            </div>
                            <div class="right">
                                <div class="row name-step">
                                    <div class="number">3</div>
                                    <div class="name">Способы оплаты:</div>
                                </div>
                                <div class="checkboxes">
                                    <label>
                                        <input type="radio" name="form_order_field_payment" value="2" checked>
                                        <span class="name">Наличными курьеру</span>
                                        <span>Курьер подъедет в удобное для Вас время, предварительно предупредив по телефону. Оплата только наличными.</span>
                                    </label>
                                    <label>
                                        <input type="radio" name="form_order_field_payment" value="1" id="pay-card">
                                        <span class="name">Картой VISA / MASTERCARD</span>
                                        <span>После оплаты билеты будут отправлены на ваш e-mail</span>
                                        <img src="/images/payment-final-2.png">
                                    </label>
                                    <div class="error-field" id="error_field_payment"></div>
                                    <input id="form_order_field_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                    <div class="btn buy" id="form-order-button">купить билет</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="info-block" data-info-block="how-give">
                        <div class="header">
                            <h2>Как заказать</h2>
                            <img src="images/icon-close-modal.svg" alt="" class="close_info">
                        </div>
                        <div class="info-content">
                            <div class="wrap">
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                    <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                    <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                    <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="btn-back"><img src="/images/arrow-left.png" alt="">Назад</div>
                        </div>
                    </div>
                    <div class="info-block" data-info-block="sale">
                        <div class="header">
                            <h2>Оплата</h2>
                            <img src="images/icon-close-modal.svg" alt="" class="close_info">
                        </div>
                        <div class="info-content">
                            <div class="wrap">
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                    <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                    <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                    <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="btn-back"><img src="/images/arrow-left.png" alt="Назад" title="Назад">Назад</div>
                        </div>
                    </div>
                    <div class="info-block" data-info-block="contact">
                        <div class="header">
                            <h2>Контакты</h2>
                            <img src="/images/icon-close-modal.svg" alt="" class="close_info">
                        </div>
                        <div class="info-content">
                            <div class="wrap">
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_1">Правила заказа билетов</h3>
                                    <p>Оформляя заказ, Покупатель заключает с ООО «ТИВО» договор об оказании услуг, связанных с приобретением билетов на условиях, изложенных в настоящих Правилах. Договор считается заключенным с момента завершения Покупателем процедуры заказа и подтверждения его ООО «ТИВО» и до момента получения Покупателем (или уполномоченным им лицом) билетов или аннулирования заказа.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_2">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_3">Срок действия заказа:</h3>
                                    <p>1. При оплате банковской картой, электронной наличностью и т.д. - до 24 часов в зависимости от даты проведения мероприятия.</p>
                                    <p>2. Прием заказов билетов через Интернет прекращается через час после времени начала мероприятия, указанного в информации о концерте.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_4">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                                <div class="how_to_block">
                                    <h3 class="big-title" id="how_to_5">Способы заказа билетов</h3>
                                    <p>Покупатель может заказать билеты, оформив заказ online на <a class="link_blue" href="https://widget.tiwo.ru" target="_blank">widget.tiwo.ru</a>. Для заказов, оформленных через интернет, количество билетов, оформленных в один заказ, не может превышать 10 штук. ООО «ТИВО» вправе вводить дополнительные ограничения по количеству реализуемых билетов одному Покупателю в зависимости от востребованности мероприятия и истории заказов Покупателя. Заказы не подлежат редактированию.</p>
                                </div>
                            </div>
                        </div>
                        <div class="footer">
                            <div class="btn-back"><img src="/images/arrow-left.png" alt="">Назад</div>
                        </div>
                    </div>
                </div>
                <div class="footer-menu">
                    <ul class="left">
                        <li><a href="#" data-show-block="how-give">Как заказать?</a></li>
                        <li><a href="#" data-show-block="sale">Оплата</a></li>
                        <li><a href="#" data-show-block="contact">Контакты</a></li>
                    </ul>
                    <div class="right phone">
                        <a href="tel:+74951505802">+7 (495) 150-58-02</a>
                    </div>
                </div>
                <div class="message">
                    <div class="text" data-message="2">
                        <p>Вы действительно желаете<br>закончить покупку билетов?</p>
                        <div class="btn buy white" data-close-modal>Выйти</div>
                        <div class="btn buy" data-close-message>Продолжить покупку</div>
                    </div>
                    <div class="text" data-message="3">
                        <p>Вы действительно желаете<br>очистить заказ?</p>
                        <div class="btn buy white" data-clear-cart>Очистить</div>
                        <div class="btn buy" data-close-message>Закрыть окно</div>
                    </div>
                    <div class="text" data-message="ticket-delete">
                        <p>Вы действительно желаете<br>удалить билет?</p>
                        <div class="btn buy white" data-ticket-delete>Удалить</div>
                        <div class="btn buy" data-close-message>Закрыть окно</div>
                    </div>
                    <div class="overlay"></div>
                </div>
            </div>
            <div class="overlay"></div>
        </div>

    <?php endif; ?>
    <div class="button-up"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>