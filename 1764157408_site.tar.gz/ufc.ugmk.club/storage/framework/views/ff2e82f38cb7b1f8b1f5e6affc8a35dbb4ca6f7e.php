<?php if($colors): ?>
    <div class="map-prices">
        <span class="caption">Фильтр по цене:</span>
        <ul>
            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($color['available']): ?>
                    <li p-min="<?php echo e($color['from']); ?>" p-max="<?php echo e($color['to']); ?>">
                        <p class="price"><?php echo e($color['title']); ?></p>
                        <div class="line" style="background:#<?php echo e($color['color']); ?>"></div>
                        <div class="tooltip"><?php echo e($color['label']); ?></div>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="map-scheme">
    <div class="tooltip" data-for="place">
        <p class="about-price"><span></span> ₽</p>
        <p class="about-sector"></p>
        <div class="block-right">
            <span class="about-row">
                <span>ряд</span>
                <span class="number"></span>
            </span>,
            <span class="about-place">
                <span>место</span>
                <span class="number"></span>
            </span>
        </div>
    </div>
    <div class="tooltip" data-for="sector">
        <p class="name"></p>
        <div class="about-price"><span class="number"></span></div>
        <div class="free-place">Свободных мест: <span class="number"></span></div>
    </div>
    <div class="hover-place"></div>
    <svg id="svg-map" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0" y="0">
        <g id="svg-map-container">
            <filter id="dropShadow" x="-100%" y="-100%" width="300%" height="300%">
                <feDropShadow stdDeviation="3" flood-color="#444" flood-opacity=".5" dx="0" dy="0"></feDropShadow>
            </filter>
            <g class="sh-decor">
                <image href="<?php echo e(url('images/scheme_decor.png')); ?>" x="0" y="1.5" width="7846px" height="3456px" />
            </g>

            <?php $__currentLoopData = $svg_conf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <g class="sh-sector" sn="<?php echo e($sector['title']); ?>" sid="<?php echo e($sector['id']); ?>" fp="<?php echo e(count($sector['places'])); ?>" pc="<?php echo e($sector['price_min'] == $sector['price_max'] ? $sector['price_min'] : $sector['price_min'] . ' - ' . $sector['price_max']); ?> ₽">
                    <?php $__currentLoopData = $sector['places']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <circle class="pa" cx="<?php echo e($place['x']); ?>" cy="<?php echo e($place['y']); ?>" r="<?php echo e($sector['place_radius']); ?>"<?php echo e($sector['place_radius_max'] ? ' mx=' . $sector['place_radius_max'] : ''); ?> pp="<?php echo e($place['place']); ?>" pr="<?php echo e($place['row']); ?>" ps="<?php echo e($place['price']); ?>" style="fill: #<?php echo e($place['color']); ?>; stroke: #<?php echo e($place['color']); ?>" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <path class="sh-path" d="<?php echo e($sector['path']); ?>"/>
                </g>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <g class="sh-actived-places"></g>
        </g>
    </svg>
    <div class="controls">
        <button class="change-zoom svg-map-button" type="button" data-zoom_type="+"><img src="images/icon-controll-plus.png"></button>
        <button class="change-zoom svg-map-button disabled" type="button" data-zoom_type="-"><img src="images/icon-controll-minus.png"></button>
        <button class="disabled" id="reset" type="button">
            <img src="images/icon-controll-home.png" alt="">
        </button>
    </div>
</div>
<script>
    //Init SVG
    var svg = d3.select("#svg-map"),
        svg_width = svg.node().getBoundingClientRect().width,
        svg_height = svg.node().getBoundingClientRect().height,

        container = d3.select("#svg-map-container"),
        container_width = container.node().getBoundingClientRect().width,
        container_height = container.node().getBoundingClientRect().height,

        controlWidth = parseFloat($('.controls').width()) + parseFloat($('.controls').css('right')) + 5,
        scale_coof = 0.5,
        init_scale = d3.min([(svg_width - controlWidth) / container_width, svg_height / container_height]),
        init_x = (svg_width - controlWidth) / 2 - container_width / 2 * init_scale,
        init_y = svg_height / 2 - container_height / 2 * init_scale,
        scale_max = init_scale + 2.5 * scale_coof,

        sizeActiveCircle = 3,
        maxSizeActiveCircle = 4.5,

        borderCoef = 1.5,

        zoom = d3.zoom().on("zoom", zoomed).on("end", check_zoom),

        tooltipPlace = d3.select('.map-scheme .tooltip[data-for="place"]'),
        tooltipSector = d3.select('.map-scheme .tooltip[data-for="sector"]'),
        hoverPlace = d3.select('.map-scheme .hover-place'),
        showPlace = true,
        activedPlaces = d3.select('.sh-actived-places');

    $('[mx]').each(function() {
        $(this).attr('old-r', $(this).attr('r'));
    });

    svg.call(zoom).on("wheel.zoom", null).on("dblclick.zoom", null);;
    wrapper = d3.select('.map-scheme');

    svg.call(zoom.transform, d3.zoomIdentity.translate(init_x, init_y).scale(init_scale)).call(removeSpiner);

    var SC = new ShopingCart();
    d3.selectAll('.svg-map-button').on('click', zoomClick);
</script>