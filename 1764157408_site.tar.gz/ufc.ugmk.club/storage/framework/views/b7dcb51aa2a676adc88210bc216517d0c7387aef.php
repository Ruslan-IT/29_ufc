<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo e($page_title . ' - ' . config('app.name', 'Event System')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/bootstrap-extend.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/zebra_datepicker/zebra_datepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/bootstrap-switch/switch.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/select2/dist/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/master_style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/_all-skins.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin/style.css')); ?>">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="hold-transition skin-black sidebar-mini">
    <div class="wrapper">
        <header class="main-header">
            <nav class="navbar navbar-static-top">
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                </a>

                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown notifications-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="mdi mdi-bell"></i>
                            </a>
                            <ul class="dropdown-menu scale-up">
                                <li class="header">You have 3 notifications</li>
                                <li>
                                    <ul class="menu inner-content-div">
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-users text-aqua"></i> Curabitur id eros quis nunc suscipit blandit.
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-warning text-yellow"></i> Duis malesuada justo eu sapien elementum, in semper diam posuere.
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-users text-red"></i> Donec at nisi sit amet tortor commodo porttitor pretium a erat.
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer"><a href="#">View all</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>

        <aside class="main-sidebar">
            <section class="sidebar">
                <div class="user-panel">
                    <div class="image">
                        <img src="<?php echo e(asset('/images/admin/user_icon.png')); ?>" class="rounded-circle" alt="admin">
                    </div>
                    <div class="info">
                        <p>admin</p>
                        <a href="<?php echo e(url('/auth/logout')); ?>" class="link" data-toggle="tooltip" title="" data-original-title="Выйти"><i class="ion ion-power"></i></a>
                    </div>
                </div>

                <ul class="sidebar-menu" data-widget="tree">
                    <li class="nav-devider"></li>
                    <li><a href="<?php echo url('admin'); ?>"><i class="fa fa-home"></i> <span>Главная панель</span></a></li>
                    <li><a href="<?php echo url('admin/events'); ?>"><i class="fa fa-star"></i> <span>Cобытия</span></a></li>
                    <li><a href="<?php echo url('admin/locations'); ?>"><i class="fa fa-institution"></i> <span>Локации</span></a></li>
                    <li><a href="<?php echo url('admin/schemes'); ?>"><i class="fa fa-image"></i> <span>Схемы площадок</span></a></li>
                    <li><a href="<?php echo url('admin/orders'); ?>"><i class="fa fa-dollar"></i><span>Заказы</span></a></li>
                </ul>
            </section>
        </aside>

        <div class="content-wrapper">
            <section class="content-header">
                <?php if(isset($page_title)): ?>
                    <h1><?php echo e($page_title); ?></h1>
                <?php endif; ?>

                <?php if(!empty($breadcrumbs)): ?>
                    <ol class="breadcrumb">
                        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="breadcrumb-item<?php echo empty($breadcrumb['link']) ? ' active' : ''; ?>">
                                <?php if(empty($breadcrumb['link'])): ?>
                                    <?php echo $breadcrumb['title']; ?>

                                <?php else: ?>
                                    <a href="<?php echo e($breadcrumb['link']); ?>"><?php echo $breadcrumb['title']; ?></a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                <?php endif; ?>
            </section>

            <section class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/vendor_components/jquery/dist/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/zebra_datepicker/zebra_datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/popper/dist/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/fastclick/lib/fastclick.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor_components/select2/dist/js/i18n/ru.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/template.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/demo.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/d3/d3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/script.js')); ?>"></script>

</body>
</html>
