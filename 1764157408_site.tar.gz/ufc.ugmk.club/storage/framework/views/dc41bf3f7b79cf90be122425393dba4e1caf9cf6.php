<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/fullpage.js/dist/jquery.fullpage.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/jquery/dist/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/fullpage.js/dist/jquery.fullpage.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/d3/d3.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/inputmask/dist/jquery.inputmask.bundle.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDsiAqp-ZEVgUwVjsbvrGFzNvkNGTf_IQY&libraries=places&callback=initMap"></script>
</body>
</html>
