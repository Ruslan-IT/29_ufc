<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Возникли ошибки
        </div>
    <?php endif; ?>

    <?php if(session()->has('message_success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo e(session()->get('message_success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->has('message_error')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo e(session()->get('message_error')); ?>

        </div>
    <?php endif; ?>


    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Все участники</h3>
            <div class="box-controls pull-right">
                <a class="btn btn-info" href="<?php echo url('admin/participants/create'); ?>">Добавить</a>
            </div>
        </div>
        <div class="box-body">
            <?php if(count($participants)): ?>
                <div class="table-responsive">
                    <table class="table table-separated">
                        <tbody>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Название</th>
                            <th>Сортировка</th>
                            <th style="width: 40px">Действия</th>
                        </tr>
                        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($participant->status ? 'bg-pale-success' : 'bg-pale-pink'); ?>">
                                <td><?php echo e($participant->id); ?></td>
                                <td><?php echo e($participant->name); ?></td>
                                <td><?php echo e($participant->sort); ?></td>
                                <td><a href="<?php echo e(url('admin/participants/' . $participant->id . '/edit')); ?>" class="btn btn-block btn-info btn-xs">Изменить</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>Нет участников</p>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>