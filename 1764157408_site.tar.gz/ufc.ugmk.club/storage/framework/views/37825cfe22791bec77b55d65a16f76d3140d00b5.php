<?php $__env->startSection('content'); ?>
    <?php if($events): ?>
        <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="box card-inverse bg-img text-center py-80" style="background-image: url(<?php echo e($event['image']); ?>)" data-overlay="5">
                        <div class="card-body">
                            <span class="bb-1 opacity-80 pb-2"><?php echo e($event['date']); ?></span>
                            <br><br>
                            <h3><?php echo e($event['title']); ?></h3>
                            <br><br>
                            <a class="btn btn-outline no-radius btn-light btn-default" href="<?php echo e($event['edit_link']); ?>">Изменить</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <p>Нет активных событий</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>