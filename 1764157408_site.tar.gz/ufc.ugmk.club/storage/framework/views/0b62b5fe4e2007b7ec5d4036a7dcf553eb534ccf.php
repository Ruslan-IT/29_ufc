<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Возникли ошибки
        </div>
    <?php endif; ?>

    <?php echo e(Form::open(['url' => 'admin/participants', 'method' => 'post', 'files' => true])); ?>

        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Добавить</h3>
            </div>
            <div class="box-body">
                <?php echo $__env->make('admin.participant.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="box-footer">
                <?php echo e(Form::submit('Добавить', ['class' => 'btn btn-success'])); ?>

                <a href="<?php echo e($cancel_link); ?>" class="btn btn-danger">Отменить</a>
            </div>
        </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>