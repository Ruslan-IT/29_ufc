<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Трибьют Григория Лепса — концерт в Москве</title>
    <meta name="description" content="Трибьют Григория Лепса, концерт в Москве, 16 июля 2018, 20:00, Олимпийский">

    <meta property="og:title" content="Трибьют Григория Лепса — концерт в Москве">
    <meta property="og:description" content="Трибьют Григория Лепса, концерт в Москве, 16 июля 2018, 20:00, Олимпийский">
    <meta property="og:image" content="http://ticketleps.ru/images/image-meta.jpg">
    <meta property="og:image:width" content="400">
    <meta property="og:image:height" content="250">
    <meta property="og:type" content="website">
    <meta property="og:url" content="http://ticketleps.ru/">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Трибьют Григория Лепса — концерт в Москве">
    <meta name="twitter:description" content="Трибьют Григория Лепса, концерт в Москве, 16 июля 2018, 20:00, Олимпийский">
    <meta name="twitter:image" content="http://ticketleps.ru/images/image-meta.jpg">

    <script language = "JavaScript">
        function preloader() {
            heavyImage = new Image();
            heavyImage.src = "images/Ripple-1.7s-150px.gif";
        }
    </script>
    <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon">
    <style>
        body img.load{
            content:'';
            width: 150px;
            height: 150px;
            position: fixed;
            top: 50%;
            left: 50%;
            z-index: 16;
            transform: translate(-50%, -50%);
            background: url('') center center no-repeat;
            background-size: contain;
        }
        body{
            overflow: hidden;
        }
        body.hide-spiner{
            overflow: auto;
        }
        body.hide-spiner:before{
            opacity: 0;
            z-index: -1;
            transition: opacity .2s, z-index 0s .2s;
        }
        body.hide-spiner img.load{
            opacity: 0;
            z-index: -1;
            transition: opacity .2s, z-index 0s .2s;
        }
        body:before{
            content:'';
            position: fixed;
            width: 100%;
            height: 100%;
            background: #f7f7f7;
            top: 0;
            left: 0;
            z-index: 15;
            transition: opacity .2s, z-index 0s 0s;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/fullpage.js/dist/jquery.fullpage.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor_components/fancybox/dist/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
</head>
<body onLoad="javascript:preloader()">
    <img src="images/Ripple-1.7s-150px.gif" alt="" class="load">

    <?php echo $__env->yieldContent('content'); ?>

    <div style="display: none;" id="fancybox-modal" class="modal-message">
        <div class="title"></div>
        <p class="message">Вы действительно желаете закончить покупку билетов?</p>
        <div class="buttons"></div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/jquery/dist/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/fullpage.js/dist/jquery.fullpage.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/d3/d3.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/inputmask/dist/jquery.inputmask.bundle.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/vendor_components/fancybox/dist/jquery.fancybox.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
    <?php if($modal_message): ?>
        <script>
            $(function() {
                modal_success(true, '<?php echo $modal_message; ?>');
            });
        </script>
    <?php endif; ?>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDsiAqp-ZEVgUwVjsbvrGFzNvkNGTf_IQY&libraries=places&callback=initMap"></script>
</body>
</html>
