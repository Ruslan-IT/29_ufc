<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Возникли ошибки
        </div>
    <?php endif; ?>

    <?php echo e(Form::model($scheme, ['url' => 'admin/schemes/' . $scheme->id, 'method' => 'put', 'files' => true])); ?>

        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Изменить</h3>
            </div>
            <div class="box-body">
                <?php echo $__env->make('admin.scheme.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="box-footer">
                <?php echo e(Form::submit('Сохранить', ['class' => 'btn btn-success'])); ?>

                <a href="<?php echo e($cancel_link); ?>" class="btn btn-danger">Отменить</a>
                <button class="btn btn-danger pull-right object-delete" data-action="<?php echo e(url('admin/schemes/' . $scheme->id)); ?>" type="button">Удалить</button>
            </div>
        </div>
    <?php echo e(Form::close()); ?>


    <?php echo e(Form::open(['method' => 'delete', 'url' => 'admin/schemes/' . $scheme->id, 'id' => 'object-form-delete'])); ?>

    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>