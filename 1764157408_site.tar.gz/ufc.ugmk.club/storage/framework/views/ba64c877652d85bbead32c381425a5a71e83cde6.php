<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            Возникли ошибки
        </div>
    <?php endif; ?>

    <h4><strong>Локация: </strong><?php echo e($scheme->getLocationName()); ?></h4>

    <div class="row">
        <div class="col-xl-6 col-md-6 col-12">
            <div class="box box-body text-center bg-blue">
                <div class="font-size-40 font-weight-200"><?php echo e($sector_count); ?></div>
                <div>Секторов</div>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 col-12">
            <div class="box box-body text-center bg-blue">
                <div class="font-size-40 font-weight-200"><?php echo e($place_count); ?></div>
                <div>Мест</div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>