<div class="row">
	<div class="col-xl-6 col-lg-12">

        <div class="form-group">
            <?php echo Form::label('status', 'Активность', [], false); ?>

            <button type="button" class="switch-button btn btn-toggle btn-primary<?php echo e(isset($scheme) && $scheme->status ? ' active' : ''); ?>" data-toggle="button" aria-pressed="true" data-switch_hidden_id="field_scheme_status">
                <span class="handle"></span>
            </button>
            <?php echo e(Form::hidden('status', null, ['class' => 'switch-hidden', 'data-switch_hidden_id' => 'field_scheme_status'])); ?>

        </div>

		<div class="form-group<?php echo e(empty($errors->get('name')) ? '' : ' has-error'); ?>">
			<?php echo Form::label('name', 'Название схемы площадки <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

        <div class="form-group<?php echo e(empty($errors->get('location_id')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('location_id', 'Локация <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::select('location_id', $locations, null, ['class' => 'form-control select-select2'])); ?>

            <?php $__currentLoopData = $errors->get('location_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('image_width')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('image_width', 'Ширина схемы площадки, px', [], false); ?>

            <?php echo e(Form::text('image_width', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('image_width'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('image_height')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('image_height', 'Высота схемы площадки, px', [], false); ?>

            <?php echo e(Form::text('image_height', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('image_height'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('scheme_image')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('scheme_image', 'Изображение схемы', [], false); ?>

            <div class="file-image-button">
                <label>
                    <?php echo e(Form::file('scheme_image', null, ['class' => 'form-control'])); ?>

                    <div class="btn btn-info">Выбрать файл</div>
                </label>
                <div class="file-image-button-image">
                    <?php if($scheme_image): ?>
                        <img src="<?php echo e($scheme_image); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <?php $__currentLoopData = $errors->get('scheme_image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

	</div>
</div>