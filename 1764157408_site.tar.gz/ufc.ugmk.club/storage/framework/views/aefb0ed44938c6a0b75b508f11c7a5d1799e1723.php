<div class="row">
	<div class="col-xl-6 col-lg-12">

        <div class="form-group">
            <button type="button" class="switch-button btn btn-toggle btn-primary<?php echo e(isset($event) && $event->status ? ' active' : ''); ?>" data-toggle="button" aria-pressed="true" data-switch_hidden_id="field_event_status">
                <span class="handle"></span>
            </button>
            <?php echo e(Form::hidden('status', null, ['class' => 'switch-hidden', 'data-switch_hidden_id' => 'field_event_status'])); ?>

        </div>

		<div class="form-group<?php echo e(empty($errors->get('name')) ? '' : ' has-error'); ?>">
			<?php echo Form::label('name', 'Название события <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

        <div class="form-group<?php echo e(empty($errors->get('image')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('image', 'Картинка', [], false); ?>

            <div class="file-image-button">
                <label>
                    <?php echo e(Form::file('image', null, ['class' => 'form-control'])); ?>

                    <div class="btn btn-info">Выбрать файл</div>
                </label>
                <div class="file-image-button-image">
                    <?php if($event_image): ?>
                        <img src="<?php echo e($event_image); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('date_start')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('date_start', 'Дата/время начала события <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::text('date_start', null, ['class' => 'form-control zebra-datepicker zebra-datepicker-range-start'])); ?>

            <?php $__currentLoopData = $errors->get('date_start'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('date_end')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('date_end', 'Дата/время завершения события <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::text('date_end', null, ['class' => 'form-control zebra-datepicker zebra-datepicker-range-end'])); ?>

            <?php $__currentLoopData = $errors->get('date_end'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group<?php echo e(empty($errors->get('scheme_id')) ? '' : ' has-error'); ?>">
            <?php echo Form::label('scheme_id', 'Схема площадки <span class="text-danger">*</span>', [], false); ?>

            <?php echo e(Form::select('scheme_id', $schemes, null, ['class' => 'form-control select-select2'])); ?>

            <?php $__currentLoopData = $errors->get('scheme_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="help-block"><?php echo e($error_item); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="form-group">
            <label>Метод задания цен</label>
            <div>
                <?php echo Form::radio('price_method', 0, $event_price_method == 0 ? true : false, ['class' => 'with-gap', 'id' => 'price_method_type_0']); ?>

                <label for="price_method_type_0">Вручную</label>
            </div>
            <div>
                <?php echo Form::radio('price_method', 1, $event_price_method == 1 ? true : false, ['class' => 'with-gap', 'id' => 'price_method_type_1']); ?>

                <label for="price_method_type_1">Парсер Яндекс.Афиша</label>
            </div>
            <div>
                <?php echo Form::radio('price_method', 2, $event_price_method == 2 ? true : false, ['class' => 'with-gap', 'id' => 'price_method_type_2']); ?>

                <label for="price_method_type_2">Смешанный</label>
            </div>
            <?php if(isset($event)): ?>
                <a class="btn btn-success btn-sm" href="<?php echo e(url('/admin/events/' . $event->id . '/price')); ?>">Редактирование цен</a>
            <?php endif; ?>
        </div>
	</div>
</div>